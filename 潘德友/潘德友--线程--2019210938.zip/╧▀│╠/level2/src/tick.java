public class tick {
    public static void main(String[] args) {
        station Station1 = new station("一号窗口");
        station Station2 = new station("二号窗口");
        station Station3 = new station("三号窗口");

            Station1.start();
            Station2.start();
            Station3.start();

    }
}
