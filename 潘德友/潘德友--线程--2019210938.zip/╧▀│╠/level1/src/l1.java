public class l1{
    public static void main(String[] args) {
        int i;
        System.out.println("dsy同学睡着了");
        for (i=1;i<100;i++){
            Level1 l=new Level1();
            l.start();
            if(i==3){
            new ll().start();
             break;
            }
        }
    }
}
