public class Level1 extends Thread{
     private int i;
     public void run(){
             System.out.println("上课!");
}
}


