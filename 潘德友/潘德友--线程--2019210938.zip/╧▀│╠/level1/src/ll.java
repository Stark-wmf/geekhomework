public class ll extends Thread{

        public void run(){
            System.out.println("dsy同学被老师叫醒\ndsy同学开始认真听讲");
        }
}

