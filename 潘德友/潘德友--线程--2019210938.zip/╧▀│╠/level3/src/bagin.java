public class bagin {
    public static void main(String[] args) {

        sl Sl=new sl();
        spx Spx=new spx();
        start Stard=new start();
        Sl.start();
        Spx.start();
        Stard.run();

    }
}
