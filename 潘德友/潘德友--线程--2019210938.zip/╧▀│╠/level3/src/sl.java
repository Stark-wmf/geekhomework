public class sl extends Thread {
    public void run(){
        System.out.println("sl来到了小卖部");
        System.out.println("sl正在等待慢吞吞的spx");
        try {
            Thread.sleep(1000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
    }
}
