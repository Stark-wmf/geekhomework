public class spx extends Thread {
    static int spx=5;
    public void run(){
        try {
            Thread.sleep(1000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        System.out.println("spx来到小卖部了");
        System.out.println("spx买到了辣条");
    }
}
