package level4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
//         * 键盘输入一个字符串，输出其中各种字符出现的次数。
//         * 种类有：大写字母、小写字母、数字他字符、其
//         * 将每种种类分别存储起来(ASCII码)
//         * 将大写字母，小写字母用升序排列输出
//         * 数字和其他字符用降序排列输出
public class level32 {
    public static void main(String[] args) {
//        * 键盘输入一个字符串，输出其中各种字符出现的次数。
        ArrayList<Character> list = new ArrayList<>();
        ArrayList<Character> lis = new ArrayList<>();
        ArrayList<Character> li = new ArrayList<>();
        ArrayList<Character> l = new ArrayList<>();
        int num=0,count=0,assess=0,calculate=0;
        Scanner in=new Scanner(System.in);
        System.out.println("请输入一个字符串:");
        String str=new String();
        str=in.nextLine();
        for(int i=0;i<str.length();i++){
            char s=str.charAt(i);
            if(s>='A'&&s<='Z'){
                list.add(s);
                num++;
            }else if(s>='a'&&s<='z'){
                lis.add(s);
                count++;
            }else if(s>='0'&&s<='9'){
                li.add(s);
                assess++;
            }else{
                l.add(s);
                calculate++;
            }
        }
        Collections.sort(list);
        Collections.sort(lis);
        Collections.sort(li);
        Collections.reverse(li);
        Collections.sort(l);
        Collections.reverse(l);
        System.out.println("大写字母出现了:"+num+"次"+"\n"+"小写字母出现了:"+count+"次"+"\n"+"数字字符出现了:"+assess+"次"+"\n"+"其他字符出现了:"+calculate+"次");
        System.out.println(list);
        System.out.println(lis);
        System.out.println(li);
        System.out.println(l);
    }
}
