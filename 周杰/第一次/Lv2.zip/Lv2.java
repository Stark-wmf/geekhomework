import com.sun.deploy.security.SelectableSecurityManager;

import javax.swing.*;
import java.util.Scanner;

public class Lv2 {

    public static void main(String[] args) {
        int n;
        int i;
        System.out.println("这是一个判断素数的程序，请输入你要判断的数");
        Scanner in = new Scanner(System.in);
        n = in.nextByte();
        for (i = 2; i<n;i++){
            if (n % i==0) {
                System.out.println("该数不是素数");
            }else{
                System.out.println("该数是素数");
            }break;
        }
    }
}
