import java.util.Scanner;

public class Lv1 {

    public static  void main(String[] args){
        System.out.println("请输入身高（米）");
        Scanner in = new Scanner(System.in);
        double meter;
        double feet = 0.3048;
        meter = in.nextDouble();
        System.out.println(meter+"/"+feet+"="+(meter/feet));
    }
}
