public class 九九乘法表 {

    public static void main(String[] args) {
        //一
        int[][] a=new int[10][10];
        for (int i = 1; i < a.length; i++) {
            a[i] = new int[i + 1];
            for (int j = 1; j < a[i].length; j++) {
                a[i][j] = (i) * (j);
                if (a[i][j]<10) {
                    System.out.print((j) + "*" + (i) + "= " + a[i][j] + "\t");
                }else {
                    System.out.print((j) + "*" + (i) + "=" + a[i][j] + "\t");
                }
            }
            System.out.println();
            }
            //二
        int arr[][] = new int[10][10];
            for (int i = 1; i <arr.length; ++i) {
                arr[i] =new int[11-i];
                for (int j =1; j<arr[i].length; j++) {
                    arr[i][j] = (i) * (10-j);
                    if (arr[i][j]<10) {
                        System.out.print((i) + "*" + (10 - j) + "= " + arr[i][j] + "\t");
                    }else {
                        System.out.print((i) + "*" + (10 - j) + "=" + arr[i][j] + "\t");
                    }
                }
                System.out.println();
            }
            //三
            int[][] b=new int[10][10];
            for (int i = 1; i < b.length; i++) {
                b[i] = new int[i + 1];
                for (int k=1;k<(10-i);k++){
                    System.out.print("        ");
                }
                for (int j = 1; j < b[i].length; j++) {
                    b[i][j] = (i) * (j);
                    if (b[i][j]<10) {
                        System.out.print((j) + "*" + (i) + "= " + b[i][j] + "\t");
                    }else {
                        System.out.print((j) + "*" + (i) + "=" + b[i][j] + "\t");
                    }
                }
                System.out.println();
            }
            //四
            int[][] c=new int[10][10];
            for (int i = 1; i <c.length; ++i) {
                c[i] =new int[11-i];
                for (int j =1; j<c[i].length; j++) {
                    c[i][j] = (i) * (10-j);
                    if (c[i][j]<10) {
                        System.out.print((i) + "*" + (10 - j) + "= " + c[i][j] + "\t");
                    }else {
                        System.out.print((i) + "*" + (10 - j) + "=" + c[i][j] + "\t");
                    }
                }
                System.out.println();
            }
        }
    }

