package com.company;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
	int j,x,y;
	Scanner i = new Scanner(System.in);
    System.out.println("请输入一个整数:");
	y = i.nextInt();
	j = (int)y/2;
	for(x=2;x<=j;x++){
	    if(y%x==0){
	        System.out.println("此数不为素数");
	        break;
        }
        }
	if(x>j){
	    System.out.println("此数为素数");
    }
    }
}
