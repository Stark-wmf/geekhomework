package com.company;
import java.util.Scanner;
public class Main{
    public static void main(String[] args) {
        System.out.println("姚明的身高为：");
        Scanner scanner= new Scanner(System.in);
        double meter= scanner.nextDouble();
        System.out.println("对应的英尺:"+meter*3.28);
        }
    }
