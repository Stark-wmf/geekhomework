package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        System.out.println("请输入钱数");
        Scanner coin = new Scanner(System.in);
        int RMB = coin.nextInt();
        for(int a = 0; a <=RMB/5; a++) {
            for (int b = 0; b <= (RMB-5*a)/2; b++) {
                int k = RMB-5*a-2*b;
                System.out.println("需要五元硬币的个数为"+a+"需要二元硬币的个数为"+b+"需要一元硬币的个数为"+k);
            }
        }
    }
}
