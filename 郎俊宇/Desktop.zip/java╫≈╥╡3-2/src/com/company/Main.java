package com.company;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("请输入钱数");
        Scanner coin = new Scanner(System.in);
        float RMB = coin.nextFloat();
        for (int a = 0; a*5 <= RMB *10; a++){
            for (int b = 0; b *2 <= (RMB*10 - a ) ; b++){
                for(int c=0 ; c <= (RMB*10 - a*5 - b*2 );c++) {
                    if (RMB*10==a*5+b*2+c)
                    System.out.println("需要0.5元硬币的个数为" + a + "需要0.2元硬币的个数为" + b + "需要0.1元硬币的个数为" + c);
                }
            }
        }
    }
}
