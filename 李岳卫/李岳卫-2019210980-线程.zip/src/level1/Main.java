package level1;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        Thread student = new Thread(new Student());
        Thread teacher = new Thread(new Teacher());
        student.start();
        teacher.start();
        student.sleep(2000);
        if (!student.interrupted()){
            student.interrupt();
        }
    }
}
