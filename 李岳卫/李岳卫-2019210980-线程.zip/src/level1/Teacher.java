package level1;

public class Teacher implements Runnable {
    @Override
    public void run() {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                for (int x = 0;x<3;x++) {
                    System.out.println("上课了！");
        }
    }
}
