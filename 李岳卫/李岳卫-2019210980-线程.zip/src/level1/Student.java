package level1;

public class Student implements Runnable {

    @Override
    public void run() {
        System.out.println("dsy同学睡着了");
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            System.out.println("dsy同学被老师叫醒了");
            System.out.println("dsy同学开始认真听讲");
        }
    }
}

