package level3;

public class Spx implements Runnable {
    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName()+":sl我们去买辣条吧");
        Thread.yield();
        System.out.println(Thread.currentThread().getName()+":我还没到小卖部 😭，我好饿，sl等等我");
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName()+":我终于到小卖部了");
        System.out.println(Thread.currentThread().getName()+":我买了一包");
    }
}
