package level3;

import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

public class Sl implements Runnable{
    @Override
    public void run() {
        Thread.yield();
        System.out.println(Thread.currentThread().getName()+":我到小卖部了,但只有两包辣条了");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName()+":我等会spx");
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName()+":我也买了一包");
    }
}
