package level3;

public class Main {
    public static void main(String[] args) {
    Sl sl = new Sl();
    Spx spx = new Spx();
    new Thread(spx,"spx").start();
    new Thread(sl,"sl").start();

    }
}
