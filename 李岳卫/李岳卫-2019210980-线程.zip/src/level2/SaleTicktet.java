package level2;

public class SaleTicktet implements Runnable {
    private int ticket = 40;
    @Override
    public void run() {
        while (this.sale());
    }
    public synchronized boolean sale(){
        if (ticket>0){
            System.out.println(Thread.currentThread().getName()+"卖票   ticket = "+this.ticket);
            ticket--;
            return true;
        }else{
            System.out.println(Thread.currentThread().getName()+"没票了");
            return false;
        }
    }
}
