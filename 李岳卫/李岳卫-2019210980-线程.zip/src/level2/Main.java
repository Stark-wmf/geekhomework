package level2;

public class Main {
    public static void main(String[] args){
        SaleTicktet  sale = new SaleTicktet();
        new Thread(sale,"no1").start();
        new Thread(sale,"no2").start();
        new Thread(sale,"no3").start();
    }
}
