package com.student;

public class Human {

}
