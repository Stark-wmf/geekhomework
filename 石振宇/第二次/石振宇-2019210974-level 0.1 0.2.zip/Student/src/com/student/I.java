package com.student;

public class I {
    public static void main(String[] args) {
        Student i = new Student();
        i.setName("石振宇");
        i.setAge(18);
        i.setSex('男');
        i.setNum(2019210974);
        i.introduce();
    }
}
