package com.level;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Demo {
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("请输入字符串：");
        String str = scanner.next();
        char[] arr = str.toCharArray();
        ArrayList WORD = new ArrayList<>();
        ArrayList word = new ArrayList<>();
        ArrayList num = new ArrayList<>();
        ArrayList other = new ArrayList<>();
        int a = 0;
        int b = 0;
        int c = 0;
        int d = 0;
        for (char ch : arr) {
            if (ch>='A'&&ch<='Z'){
                a++;
                WORD.add(ch);
            }else if (ch>='a'&&ch<='z'){
                b++;
                word.add(ch);
            }else if (ch>='0'&&ch<='9'){
                c++;
                num.add(ch);
            }else{
                d++;
                other.add(ch);
            }

        }
        System.out.println("大写字母出现了"+a+"次");
        System.out.println("小写字母出现了"+b+"次");
        System.out.println("数字出现了"+c+"次");
        System.out.println("其他字符出现了"+d+"次");
        Collections.sort(WORD);
        Collections.sort(word);
        Collections.sort(num);
        Collections.sort(other);
        Collections.reverse(num);
        Collections.reverse(other);
        System.out.println(WORD);
        System.out.println(word);
        System.out.println(num);
        System.out.println(other);
    }
}
