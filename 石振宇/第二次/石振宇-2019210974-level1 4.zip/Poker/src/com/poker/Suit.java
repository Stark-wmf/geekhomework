package com.poker;

public class Suit extends Card {

}
