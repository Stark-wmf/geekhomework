package com.poker;

import java.util.ArrayList;
import java.util.Collections;

public class Card {
    public int s1 = 3;
    public int s2 = 4;
    public static void main(String[] args) {
        ArrayList Poker = new ArrayList<>();
        String color[] = {"spades", "clubs", "hearts", "diamonds"};
        String num[] = {"3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A", "2"};
        Poker.add("大王");
        Poker.add("小王");
        for (String s1 : color) {
            for (String s2 : num) {
                Poker.add(s1 + s2);
            }
        }
        System.out.println(Poker);
        Collections.shuffle(Poker);
        System.out.println("洗牌后：\n");
        System.out.println(Poker);

        ArrayList player1 = new ArrayList<>();
        ArrayList player2 = new ArrayList<>();
        for (int i = 0;i<Poker.size();i+=2)
        {
            player1.add(Poker.get(i));
            player2.add(Poker.get(i+1));
        }
        System.out.println("player1:"+player1);
        System.out.println("player2"+player2);


    }
}
