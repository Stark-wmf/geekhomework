package com.guess;

import java.util.Scanner;

public class NumberGuess {
    public static void main(String[] args) {
        int num = (int)(Math.random() * 100) + 1;
        System.out.println("请输入猜测的数（1-100）：");
        Scanner scanner = new Scanner(System.in);
        int x = scanner.nextInt();
        while (x != num)
        {
            if (x>num)
            {
                System.out.println("太大了！");
            }
            else
            {
                System.out.println("太小了！");
            }
            System.out.println("请输入猜测的数（1-100）：");
            x = scanner.nextInt();
        }
        if (x == num)
        {
            System.out.println("恭喜你猜对了！");
        }
    }
}
