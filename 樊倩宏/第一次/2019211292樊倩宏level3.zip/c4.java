import java.util.Scanner;

public class c4 {
    public static void main(String[] args) {
        System.out.println("请输入任意整数");
        System.out.println("请输入任意小数");
        int one=addOne(1,2,5);

        float two=addTwo(0.1f,0.2f,0.5f);
    }
    public static int addOne(int x,int y,int z){
        Scanner input=new Scanner(System.in);
        int num=input.nextInt();
        for (int i = 10; i >=0; i--) {
            for (int j = 10; j >=0 ; j--) {
                for (int k = 10; k >=0 ; k--) {
                    if(num==i*z+j*y+k*x){
                        System.out.println("需要"+i+"枚5元硬币,"+j+"枚2元硬币"+k+"枚1元硬币");
                    }
                }
            }
        }
        return num;
    }
    public static float addTwo(float x,float y,float z){
        Scanner input=new Scanner(System.in);
        float num=input.nextFloat();
        for (int i = 9; i >=0; i--) {
            for (int j = 9; j >=0; j--) {
                for (int k = 9; k >=0; k--) {
                    if(num==i*0.5+j*0.2+k*0.1){
                        System.out.println("需要"+i+"枚0.5元硬币,"+j+"枚0.2元硬币"+k+"枚0.1元硬币");
                    }

                }

            }

        }
        return num;
    }

}