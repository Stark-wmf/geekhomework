package SLhomework.Line.Level3;

import java.util.Set;

public class Shop implements Runnable {
    Thread Customer1,Customer2;
    Shop(){
        Customer1=new Thread(this);
        Customer2=new Thread(this);
    }
    @Override
    public void run() {
        String name=Thread.currentThread().getName();
        while(name.equals("sl")) {
            System.out.println(name + "开开心心的去小卖部买辣条");
            try {
                System.out.println(name + "有十元钱，商店没5元钱的零钱零钱，想到spx也要买辣条，" + name + "等待spx一起买辣条");
                Thread.sleep(1000*30);
            } catch (InterruptedException e) {
                System.out.println(name + "和spx买到了辣条");
            }
            break;
        }
        while(name.equals("spx")){
            System.out.println(name+"快速的跑去买辣条");
            try {
                Thread.sleep(1000*2);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(name+"跑到了小卖部，看见了sl");
            Customer1.interrupt();
            break;
        }
    }
}
