package SLhomework.Line.Level3;

public class Main {
    public static void main(String[] args) {
        Shop shop=new Shop();
        shop.Customer1.setName("sl");
        shop.Customer2.setName("spx");
        shop.Customer1.start();
        shop.Customer2.start();
    }
}
