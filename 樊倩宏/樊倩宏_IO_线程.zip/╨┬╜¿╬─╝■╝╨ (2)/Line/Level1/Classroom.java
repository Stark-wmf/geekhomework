package SLhomework.Line.Level1;

public class Classroom implements Runnable{
    Thread Stusent1,Teacher;
    Classroom(){
        Teacher =new Thread(this);
        Stusent1=new Thread(this);
    }
    @Override
    public void run() {
        String name=Thread.currentThread().getName();
        while(name.equals("dsy")) {
            System.out.println("我是" + name + ",我睡着了,我准备睡半个小时再开始上课！");
            try {
                Thread.sleep(1000 * 30 * 60);
            } catch (InterruptedException e) {
                System.out.println(name + "同学被老师叫醒了");
                System.out.println(name + "同学开始认真听讲");
            }
            break;
        }
        while (name.equals("老师")){
            for (int i = 0; i <3 ; i++) {
                System.out.println("上课！");
                try {
                    Thread.sleep(1000);
                }catch (InterruptedException e){
                }
            }
            Stusent1.interrupt();
            break;
        }

    }
}
