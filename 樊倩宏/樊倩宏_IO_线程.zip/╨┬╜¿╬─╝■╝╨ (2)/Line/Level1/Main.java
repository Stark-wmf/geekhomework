package SLhomework.Line.Level1;

public class Main {
    public static void main(String[] args) {
        Classroom classroom=new Classroom();
        classroom.Teacher.setName("老师");
        classroom.Stusent1.setName("dsy");
        classroom.Stusent1.start();
        classroom.Teacher.start();
    }
}
