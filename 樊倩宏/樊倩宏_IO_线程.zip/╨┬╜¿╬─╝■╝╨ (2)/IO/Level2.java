package SLhomework.IO;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static javax.imageio.ImageIO.read;
//序列化一个对象，存放在当前目录下？？？
public class Level2 {
    public static void main(String[] args) throws IOException {
        File file =new File("E:/Users");
        read(file);
    }
    public static File read(File file){
        List<File> listf=new ArrayList();
        File[]files=file.listFiles();
        if(files!=null){
            for (File fi:files
                 ) {if (file.exists()){
                     listf.add(read(fi));
                for (File list:listf
                     ) {if(list.toString().endsWith(".java")){
                    System.out.println(list);
                }
                }
            }else {
                     listf.add(fi);
                for (File list:listf
                     ) {if(list.toString().endsWith(".java")){
                    System.out.println(list);
                }
                }
            }
            }
        }
        return file;
    }
}
