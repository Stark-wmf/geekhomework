package SLhomework.level3;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int[]sysRedBall=new int[6];
        int sysBuleBall=0;
        int[]userRedBall=new int[6];
        int userBuleBall=0;
        int redCount=0;
        int blueCount=0;
        int[]redBalls={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,33,32,33};
        Random r=new Random();
        for (int i = 0; i <sysRedBall.length ; i++) {
            int index=0;
            while (true){
                index=r.nextInt(33);
                if(-1 != redBalls[index]){
                    sysRedBall[i]=redBalls[index];
                    redBalls[index]=-1;
                    break;
                }
            }

        }
        sysBuleBall=r.nextInt(16)+1;
        Scanner sc=new Scanner(System.in);

        System.out.println("请选择红色球号码，1-33之间选，选6次，不能重复");
        for (int i = 0; i < userRedBall.length; i++) {
                userRedBall[i]=sc.nextInt();

        }
        System.out.println("请选择蓝色球号码，1-16之间选，选1次");
        userBuleBall=sc.nextInt();
        for (int i = 0; i <sysRedBall.length ; i++) {
            for (int j = 0; j <userRedBall.length ; j++) {
                if(sysRedBall[i]==userRedBall[j]){
                    redCount++;
                }

            }
        }
        if(sysBuleBall==userBuleBall){
            blueCount++;
        }
        if(redCount==6&&blueCount==1){
            System.out.println("恭喜您中了一等奖，奖金1000万");
        }else if(redCount==6&&blueCount==0){
            System.out.println("恭喜您中了二等奖，奖金500万");
        }else if(redCount==5&&blueCount==1){
            System.out.println("恭喜您中了三等奖，奖金3000元");
        }else if(redCount==5&&blueCount==0||redCount==4&&blueCount==1){
            System.out.println("恭喜您中了四等奖，奖金200元");
        }else if(redCount==4&&blueCount==0||redCount==3&&blueCount==1) {
            System.out.println("恭喜您中了五等奖，奖金10元");
        }else if(redCount==2&&blueCount==1||redCount==1&&blueCount==1||redCount==0){
            System.out.println("恭喜您中了六等奖，奖金5元");
        }else {
            System.out.println("谢谢参与，下次再来！");
        }
        System.out.println("本期开奖红球号码："+Arrays.toString(sysRedBall)+"蓝球号码"+sysBuleBall);
        System.out.println("用户选择红球号码："+Arrays.toString(userRedBall)+"蓝球号码"+userBuleBall);
    }
}