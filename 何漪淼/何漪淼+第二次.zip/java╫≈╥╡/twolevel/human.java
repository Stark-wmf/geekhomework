package twolevel;

import Human.Human;

public class human {
    public static void main(String[] args){
        Student student= new Student();
        System.out.println(student.getName());
        System.out.println(student.getNum());
        System.out.println(student.getSex());
        System.out.println(student.getAge());
    }
}
