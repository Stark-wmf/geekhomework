package twolevel;

public class Student {
        //public static void main(String[] args) {
        private String name="何漪淼";
        private String sex="女";
        private int age=18;
        private int num=2019210933;


        public String getSex() {
                return sex;
        }

        public int getAge() {
                return age;
        }

        public String getName() {

                return name;
        }

        public int getNum() {
                return num;
        }
}





