package homework2;

import java.sql.SQLOutput;
import java.util.Scanner;

import static java.lang.System.*;

public class caizi {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int a = (int) (Math.random() * 100);
        int b;
        System.out.println("请输入一个数字:");
        do {
            b = input.nextInt();
            if (b > a) {
                System.out.println("嘻嘻嘻，太大啦");
            }
            if (b < a) {
                System.out.println("哎呀呀，太小咯");
            }
            if(b==a) {
                System.out.println("Wow,你真的是太聪明了！！");
                break;
            }
        } while (true);
     System.out.println("猜对了");

    }
}

