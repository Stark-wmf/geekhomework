package homework2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
    public class zuoye3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入一个字符串：");
        String str = sc.next(); // 获取键盘输入的一个字符串
        int countUpper = 0; // 大写字母
        int countLower = 0; // 小写字母
        int countNumber = 0; // 数字
        int countOther = 0; // 其他字符
        ArrayList upper = new ArrayList();
        ArrayList lower = new ArrayList();
        ArrayList number = new ArrayList();
        ArrayList other = new ArrayList();

        char[] charArray = str.toCharArray();
        for (int i = 0; i < charArray.length; i++) {
            char ch = charArray[i];
            if ('A' <= ch && ch <= 'Z') {
                upper.add(charArray[i]);
                countUpper++;
            } else if ('a' <= ch && ch <= 'z') {
                lower.add(charArray[i]);
                countLower++;
            } else if ('0' <= ch && ch <= '9') {
                number.add(charArray[i]);
                countNumber++;
            } else {
                other.add(charArray[i]);
                countOther++;
            }
        }

        System.out.println("大写字母有：" + countUpper);
        System.out.println("小写字母有：" + countLower);
        System.out.println("数字有：" + countNumber);
        System.out.println("其他字符有：" + countOther);

        Collections.sort(upper);
        Collections.sort(lower);
        Collections.sort(number);
        Collections.sort(other);
        Collections.reverse(number);
        Collections.reverse(other);

        System.out.println(upper);
        System.out.println(lower);
        System.out.println(number);
        System.out.println(other);

    }

}