package homework2;

import java.util.ArrayList;

public class card {
    public static void main(String[] args) {
        //ArrayList list = new ArrayList();
        String name = "";
        for (int i=2;i <= 16; i++) {
            if(i<=14) {
                switch (i) {
                    case 11:
                        name = "J";
                        break;
                    case 12:
                        name = "Q";
                        break;
                    case 13:
                        name = "K";
                        break;
                    case 14:
                        name = "A";
                        break;
                    default:
                        name = String.valueOf(i);
                        break;
                }
                System.out.println("spades" + name);
                System.out.println("clubs" + name);
                System.out.println("hearts" + name);
                System.out.println("diamonds" + name);
            }
            else {
                if (i == 15)
                    System.out.println("little king");
                if (i == 16)
                    System.out.println("big king");
            }
        }
    }
}


