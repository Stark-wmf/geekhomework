public class Level5three {
    public static void main(String[] args) {
            String[][]i=new String[9][9];
        for(int a = 1; a <=i.length;a++) {



                for (int b =1; b <= i.length; b++) {
                    System.out.print(a + "*" + b + "=" + (b * a) + "\t");
                }
                System.out.println();
            }
        }
    }
