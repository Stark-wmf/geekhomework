import java.util.Scanner;

public class Level2 {
        public static void main(String[] arges){
            Scanner scanner = new Scanner(System.in);
            System.out.println("请输入一个不为0的自然数:");
            int x=scanner.nextInt();
            for(int i=2;i<x;i++){
                if(x%i==0){
                    System.out.println("不是素数");
                    break;
                }else{
                    System.out.println("是素数");
                    break;
                }
            }

        }


}
