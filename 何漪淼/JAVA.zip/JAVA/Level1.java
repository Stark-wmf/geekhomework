import java.util.Scanner;

class level1 {
    public static void main(String[] arges) {
        Scanner in=new Scanner(System.in);
        double meter=in.nextDouble();
        System.out.println(meter*3.28+"英尺");
    }

}