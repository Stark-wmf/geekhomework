import java.util.Scanner;

public class Level4 {
    public static void main(String[] arges){
        Scanner in=new Scanner (System.in);
        int x=in.nextInt();
        int[] numbers=new int[10];
        while(x!=-1){
            if(x>=0 && x<=9 ){
                numbers[x]++;
            }
            x=in.nextInt();
        }
        for(int i=0;i<numbers.length;i++){
            System.out.println(i+":"+numbers[i]);
        }
    }
}
