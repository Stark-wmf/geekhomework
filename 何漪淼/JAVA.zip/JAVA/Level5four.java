public class Level5four {
    public static void main(String[] args) {
        int[][] i = new int[9][9];
        for (int a = 1; a <= i.length; a++) {
            for (int t = 1; t<= i.length - a; t++) {
                System.out.print("     \t");
            }
                for (int b =1; b <= a; b++) {
                    System.out.print(b + "*" + a + "=" + (a * b) + "\t");
                }
                System.out.println();
            }
        }
    }



