import java.util.Scanner;

public class Level3 {
    public static void main(String[] arges) {
        Scanner in = new Scanner(System.in);
        System.out.println("请输入一个面值");
        double amount = in.nextDouble() ;
            if (amount == (int) amount) {
                for (double one = 0; one <= amount; ++one) {
                    for (double two = 0; two <= amount / 2; ++two) {
                        for (double five = 0; five <= amount / 5; ++five) {
                            if (one + two + five == amount) {
                                System.out.println(one + "张1元" + two + "张2元" + five + "张5元");
                            }
                        }
                    }
                }
            } else {


                for (double one = 0; one <= amount / 0.1; ++one) {
                    for (double two = 0; two <= amount / 0.2; ++two) {
                        for (double five = 0; five <= amount / 0.5; ++five) {
                            if (one*0.1 + two*0.2 + five*0.5 == amount) {
                                System.out.println(one + "张1角" + two + "张2角" + five + "张5角");
                            }
                        }
                    }
                }

            }

    }
}






