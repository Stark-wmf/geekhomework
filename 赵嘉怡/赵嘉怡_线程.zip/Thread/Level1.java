package Thread;

public class Level1 {
    public static void main(String[] args) {
        ClassRoom classroom=new ClassRoom();
        classroom.Teacher.setName("老师");
        classroom.Student.setName("dsy");

        classroom.Teacher.start();
        classroom.Student.start();
    }
}

class ClassRoom implements Runnable{
    Thread Teacher,Student;
    ClassRoom()
    {
        Teacher = new Thread(this);
        Student = new Thread(this);
    }


    public void run()
    {
        String name=Thread.currentThread().getName();
        if(name.equals("dsy"))
        {
            try
            {
                System.out.println(name+"同学睡着了");
                Thread.sleep(1000*10*60);
            }
            catch (InterruptedException e)
            {
                System.out.println(name+"同学被老师叫醒了");
                System.out.println(name+"同学开始认真听讲");
            }
            Teacher.interrupt();
        }else{
            for(int i=1;i<=3;i++){
                System.out.println("上课！");
                try
                {
                    Thread.sleep(1000);
                }
                catch (InterruptedException ignored) {}
            }
            Student.interrupt();
        }
    }
}