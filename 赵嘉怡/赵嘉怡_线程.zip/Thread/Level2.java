package Thread;

public class Level2 {
    public static void main(String[] args) {

        Window no1 = new Window("窗口一");
        Window no2 = new Window("窗口二");
        Window no3 = new Window("窗口三");

        no1.start();
        no2.start();
        no3.start();

    }
}

class Window extends Thread {

    private static int ticket = 40;//设置静态票数
    private static final Object ob = "ThisIsATicket"; //设置线程锁

    //给线程命名
    Window(String name) {
        super(name);
    }

    public void run() {
        sell();
    }

    //售卖方法
    private void sell() {
        while (ticket > 0) {
            synchronized (ob) {					//打开

                if (ticket > 0) {

                    System.out.println(getName() + "卖了第" + ticket + "张票");
                    ticket--;
                } else {
                    System.out.println("SORRY，票卖完了");
                }
            }

            try {
                sleep((long) (1000 * Math.random()));
            } //休息
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

