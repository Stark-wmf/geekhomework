package IO;

import java.io.File;
import java.util.ArrayList;

public class IOLevel2 {
    public static void main(String[] args) {
        File file=new File("D:\\信管工作室\\11.10\\src");
        read(file);
    }

    private static File read(File file) {
        ArrayList<File> array = new ArrayList<File>();
        File[] files = file.listFiles();
        if (files != null) {
            for (File fi : files) {
                if(file.exists()){
                    array.add(read(fi));
                    for(File list:array){
                        //如果包含“.java”文件，则输出该路径
                        if(list.toString().endsWith(".java")){
                            System.out.println(list);
                        }
                    }
                }else{
                    array.add(fi);
                    for(File list:array){
                        //如果文件后缀为“.java”，则输出文件所在路径
                        if(list.toString().endsWith(".java")){
                            System.out.println(list);
                        }
                    }
                }
            }
        }
        return file;
    }
}
