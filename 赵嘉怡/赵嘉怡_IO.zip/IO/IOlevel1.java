package IO;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

class IOLevel1 {
    private static ArrayList<String> dirs=new ArrayList<>();
    private static ArrayList<String> files=new ArrayList<>();
    private static void isDir(File file){
        if(file.isDirectory()){
            dirs.add(file.getName());
            File[] list=file.listFiles();
            assert list != null;
            for(File f : list){
                isDir(f);
            }
        }else{
            files.add(file.getName());
        }
    }

    public static void main(String []args) {
        String filePath;
        Scanner in = new Scanner(System.in);
        filePath = in.nextLine();
        File file = new File(filePath);
        isDir(file);
        System.out.println("文件夹：" );
        for (String dir : IOLevel1.dirs) {
            System.out.printf("%20s", dir);
        }

        System.out.println();
        System.out.println("----------------------------------------------------------------------------------------------");
        System.out.println("文件：" );
        for (String f : IOLevel1.files) {
            System.out.printf("%40s", f);
        }
    }
}
