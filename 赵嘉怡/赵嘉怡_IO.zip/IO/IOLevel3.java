package IO;

import java.io.*;
import java.util.Scanner;

public class IOLevel3 {
    public static void main(String[] args) throws IOException {

        String url1;
        Scanner in = new Scanner(System.in);
        url1 = in.nextLine();

        String url2 = "D:\\E\\"; // 目标文件夹
        (new File(url2)).mkdirs(); // 创建目标文件夹

        File[] file = (new File(url1)).listFiles(); // 获取源文件夹当前下的文件或目录
        assert file != null;
        for (File value : file) {

            if (value.isFile()) // 复制文件
            {
                String a = value.getName().substring(
                        value.getName().lastIndexOf(".") + 1);
                copyFile(value, new File(url2 + value.getName()));
            }

            if (value.isDirectory()) // 复制目录
            {
                String sourceDir = url1 + File.separator + value.getName();
                String targetDir = url2 + File.separator + value.getName();
                copyDirectiory(sourceDir, targetDir);
            }
        }
    }

    // 复制文件
    private static void copyFile(File sourceFile, File targetFile)
            throws IOException {
        try (BufferedInputStream inBuff = new BufferedInputStream(new FileInputStream(sourceFile));
             BufferedOutputStream outBuff = new BufferedOutputStream(new FileOutputStream(targetFile)))
        {

            byte[] b = new byte[1024 * 5];
            int len;
            while ((len = inBuff.read(b)) != -1) {
                outBuff.write(b, 0, len);
            }

            outBuff.flush();
        }
    }

    // 复制文件夹
    private static void copyDirectiory(String sourceDir, String targetDir)
            throws IOException {

        (new File(targetDir)).mkdirs();

        File[] file = (new File(sourceDir)).listFiles();
        assert file != null;
        for (File value : file) {
            if (value.isFile()) {

                File targetFile = new File(
                        new File(targetDir).getAbsolutePath() + File.separator
                                + value.getName());
                copyFile(value, targetFile);
            }
            if (value.isDirectory()) {

                String dir1 = sourceDir + "/" + value.getName();

                String dir2 = targetDir + "/" + value.getName();
                copyDirectiory(dir1, dir2);
            }
        }
    }
}
