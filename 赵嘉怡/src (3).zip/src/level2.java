import java.util.Scanner;

public class level2 {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("请输入一个自然数:");
        int a = scn.nextInt();
        boolean b = true;
        for (int i = 2; i < a; i++) {
            if (a % i == 0) {
                b = false;
                break;
            }
        }
            if(b && a!=1){
            System.out.println(a + "是素数");
        } else {
            System.out.println(a + "不是素数");
        }
    }
}
