import java.util.Scanner;

public class level1 {
    public static void main(String[] args) {
        Scanner scn =new Scanner(System.in);
        System.out.println("请输入多少米");
        double meter=scn.nextDouble();
        double feet=meter/0.305;
        System.out.println("约等于"+feet+"英尺");
    }
}
