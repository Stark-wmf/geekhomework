import java.util.Scanner;

public class level4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("请输入一串数");
        int[] num = new int[10];
        int a = in.nextInt();
        for( int b=0;b<num.length;b++)
            System.out.println(num[b]);
        while (a != -1) {
            if (a >= 0 && a <= 9) ;
            {
                num[a]++;
            }
            a = in.nextInt();
        }
        for (int b = 0; b < num.length; b++) {
            System.out.println(b + "的个数为" + num[b]);
        }
    }
}

