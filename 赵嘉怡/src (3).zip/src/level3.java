import java.util.Scanner;

public class level3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("请输入一个数");
        double amount = in.nextDouble();{
            if ((int) amount == amount) {
                for (int one = 0; one <= amount; ++one) {
                    for (int two = 0; two <= amount / 2; ++two) {
                        for (int five = 0; five <= amount / 5; ++five) {
                            if (one + five * 5 + 2 * two == amount) {
                                System.out.println(one + "张1元，" + two + "张2元，" + five + "张5元");
                            }
                        }
                    }
                }
            } else{
                for (int a = 0; a <= amount / 0.1; ++a) {
                    for (int b = 0; b <= amount / 0.2; ++b) {
                        for (int c = 0; c <= amount / 0.5; ++c) {
                            if (a * 0.1 + 0.2 * b + 0.5 * c == amount) {
                                System.out.println(a + "张1角，" + b + "张2角，" + c + "张5角");
                            }
                        }
                    }
                }
            }
        }
    }
}
