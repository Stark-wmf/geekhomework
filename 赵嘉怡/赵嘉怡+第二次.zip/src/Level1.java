public class Level1 {
    public static void main(String[] args) {
        String[] a = new String[]{"黑桃", "红心", "方块", "梅花"};
        String[] b = new String[]{"3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A", "2"};
        for (String s : b)
            for (String value : a) {
                System.out.println(value + s);
            }
        System.out.println("小王\n"+"大王");
    }
}
