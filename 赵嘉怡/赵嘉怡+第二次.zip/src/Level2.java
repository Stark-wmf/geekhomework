import javax.swing.*;
import java.util.Scanner;

public class Level2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num = (int) (Math.random() * 100);
        int guess;
        System.out.println("猜0到99之间的一个整数:");
        do {
            guess = input.nextInt();
            if (num < guess) {
                System.out.println("猜错了！大了，继续小噻!");
            }
            else if (num > guess) {
                System.out.println("猜错了！小了，继续大噻!");
            }
            else {
                break;
            }
        } while (true);
        System.out.println("恭喜你猜对了!");
    }
}
