package PuKe;

public class Level1 {
    private String[] a = new String[]{"黑桃", "红心", "方块", "梅花"};
    private String[] b = new String[]{"3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A", "2"};
    public Level1() {
        for (String s : b)
            for (String value : a) {
                System.out.println(value + s);
            }
    }
}