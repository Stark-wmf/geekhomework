package dog;

public class Student {
    private String name = "赵嘉怡";
    private int age = 18;
    private String sex = "女";
    private int num = 2019210934;

    public int getAge() {
        return age;
    }

    public int getNum() {
        return num;
    }

    public String getName() {
        return name;
    }

    public String getSex() {
        return sex;
    }
}
