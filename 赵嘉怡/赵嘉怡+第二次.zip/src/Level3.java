import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Level3 {
    public static void main(String[] args) {
        Scanner sca =new Scanner(System.in);
        System.out.println("请输入一个字符串:");
        String str = sca.next();
        int countUpper = 0;
        int countLower = 0;
        int countNum = 0;
        int countOther = 0;

        ArrayList<Character> upper = new ArrayList<>();
        ArrayList<Character> lower = new ArrayList<>();
        ArrayList<Character> num = new ArrayList<>();
        ArrayList<Character> other = new ArrayList<>();

        char[] chars = str.toCharArray();
        for (char ch : chars) {
            if (ch >= 'A' && ch <= 'Z') {
                upper.add(ch);
                countUpper++;
            } else if (ch >= 'a' && ch <= 'z') {
                lower.add(ch);
                countLower++;
            } else if (ch >= '0' && ch <= '9') {
                num.add(ch);
                countNum++;
            } else {
                other.add(ch);
                countOther++;
            }
        }

        System.out.println("大写字母有：" + countUpper);
        System.out.println("小写字母有：" + countLower);
        System.out.println("数字有：" + countNum);
        System.out.println("其他字符有：" + countOther);

        Collections.sort(upper);
        Collections.sort(lower);
        Collections.sort(num);
        Collections.sort(other);
        Collections.reverse(num);
        Collections.reverse(other);

        System.out.println(upper);
        System.out.println(lower);
        System.out.println(num);
        System.out.println(other);
    }
}
