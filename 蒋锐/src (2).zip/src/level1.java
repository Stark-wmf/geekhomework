import java.util.Scanner;
public class level1 {

    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.println("请输入身高(米)");
        double m=input.nextDouble();
        double p=m/0.3048;


        System.out.println("你的身高为"+p+"英尺");
    }

}
