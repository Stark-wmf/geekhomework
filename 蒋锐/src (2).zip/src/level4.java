import java.util.Scanner;
public class level4 {
    public static void main(String[] args) {
        int []num={0,1,2,3,4,5,6,7,8,9};
        Scanner input=new Scanner(System.in);

        System.out.println("请输入0-9投票；输入-1结束投票");

        int o1=0;
        int o2=0;
        int o3=0;
        int o4=0;
        int o5=0;
        int o6=0;
        int o7=0;
        int o8=0;
        int o9=0;
        int o10=0;
        for(int i=1;i>0;i++){int p=input.nextInt();
            if(p==num[0]){
                o1+=1;}
            if(p==num[1]){
                o2+=1;
            }if(p==num[2]){
                o3+=1;
            }if(p==num[3]){
                o4+=1;
            }if(p==num[4]){
                o5+=1;
            }if(p==num[5]){
                o6+=1;
            }if(p==num[6]){
                o7+=1;
            }if(p==num[7]){
                o8+=1;
            }if(p==num[8]){
                o9+=1;
            }if(p==num[9]){
                o10+=1;
            }if(p==-1){
                break;
            }if(p>9||p<0&&p!=-1){
                System.out.println("您输入的数字有误");
            }

        }   System.out.println("0出现"+o1+"次\t"+"1出现"+o2+"次\t"+"2出现"+o3+"次\t"+"3出现"+o4+"次\t"+"4出现"+o5+"次\t"+"5出现"+o6+"次\t"+"6出现"+o7+"次\t"+"7出现"+o8+"次\t"+"8出现"+o9+"次\t"+"9出现"+o10+"次");
    }
}
