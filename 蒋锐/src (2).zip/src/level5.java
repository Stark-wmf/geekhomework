public class level5 {
    public static void main(String[] args) {
        graph1();
        System.out.println();
        graph2();
        System.out.println();
        graph3();
        System.out.println();
        graph4();



    }
    public static void graph1(){
        int [][]nums={{1,2,3,4,5,6,7,8,9},{1,2,3,4,5,6,7,8,9}};


        for(int i=0;i<nums[0].length;i++){
            for(int j = 0;j<=i; j++){
                int sum=nums[0][i]*nums[1][j];
                System.out.print(nums[1][j]+"*"+nums[0][i]+"="+sum+"\t");
            }
            System.out.println();
        }

    }
    public static void graph2(){
        int [][]nums={{1,2,3,4,5,6,7,8,9},{1,2,3,4,5,6,7,8,9}};
        for(int i=nums[0].length-1;i>=0;i--){for (int l=nums[0][i];l>1;l--){
            System.out.print("     \t");
        }
            for(int j=i;j<nums[1].length;j++){

                int sum=nums[0][i]*nums[1][j];

                System.out.print(nums[1][j]+"*"+nums[0][i]+"="+sum+"\t");

            } System.out.println();

        }
    }

    public static void graph3(){
        int [][]nums={{1,2,3,4,5,6,7,8,9},{1,2,3,4,5,6,7,8,9}};
        for (int i=nums[0].length-1;i>=0;i--){
            for(int j=0;j<=i;j++){
                int sum=nums[0][i]*nums[1][j];
                System.out.print(nums[0][i]+"*"+nums[1][j]+"="+sum+"\t");
            }
            System.out.println();
        }

    }
    public static void graph4(){int nums[][]={{1,2,3,4,5,6,7,8,9},{1,2,3,4,5,6,7,8,9}};
        for(int i=0;i<nums[0].length;i++){
            for (int l=1;l<nums[0][i];l++){
                System.out.print("     \t");
            }
            for (int j=i;j<nums[1].length;j++){
                int    sum=nums[0][i]*nums[1][j];
                System.out.print(nums[1][j]+"*"+nums[0][i]+"="+sum+"\t");
            }
            System.out.println();
        }
    }
}
