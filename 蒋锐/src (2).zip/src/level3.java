import java.util.Scanner;
public class level3 {
    public static void main(String[] args) {
        int A = 1;
        int B = 2;
        int C = 5;
        double a = 0.1;
        double b = 0.2;
        double c = 0.5;
        Scanner input = new Scanner(System.in);
        System.out.println("请输入任意金额：");
        double num = input.nextDouble();
        int p = (int) num;
        double o = num*10 - p*10;
        for (int i = p / C; i >= 0; i--) {
            for (int j = (p - i * C) / B; j >= 0; j--) {
                int h = p - i * C - j * B;


                for (int l = (int) (o/(c*10)); l >= 0; l--) {
                    for (int k = (int) ((o - l * c*10) / (b*10)); k >= 0; k--) {



                        double m =  ((o -  k*b*10- c *l*10));
                        int x=(int)m;
                        if(m>x+0.9&&m<1+x){
                            x=x+1;
                        }

                        System.out.println(num+"是由"+i+"张五元\t"+j+"张二元\t"+h+"张一元\t"+l+"张0.5元\t"+k+"张0.2元\t"+x+"张0.1元构成\t");
                    }
                }
            }
        }
    }
}
