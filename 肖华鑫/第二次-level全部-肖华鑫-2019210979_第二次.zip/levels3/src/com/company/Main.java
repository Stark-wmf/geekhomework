package com.company;
import java.util.Scanner;
import java.util.Arrays;
public class Main {

    public static void main(String[] args) {
        System.out.println("请输入字符串");
        Scanner sc = new Scanner(System.in);
        int a = 0, b = 0, c = 0, d = 0;
        String ch = sc.nextLine();
        char[] Chars1 = ch.toCharArray();
        Arrays.sort(Chars1);
        System.out.println("字母升序输出");
        for(int i=0;i<=Chars1.length - 1;i++){
            if((Chars1[i]>=97&&Chars1[i]<=125)||(Chars1[i]>=65&&Chars1[i]<=90)){
                System.out.print(Chars1[i]);
            }
        }
        System.out.println();
        char[] Chars2 = Chars1;
        for (int i = 0; i <= Chars2.length - 1; i++) {
            for (int j = 0; j <= Chars2.length - 2; j++) {
                if (Chars1[i] > Chars2[j]) {
                    char temp = Chars1[i];
                        Chars1[i] = Chars2[j];
                        Chars2[j] = temp;
                    }
                }
            }
        System.out.println("其他降序输出");
                for (int j = 0; j <= Chars1.length - 1; j++) {
                    if (Chars1[j] <= 57 && Chars1[j] >= 48) {
                        System.out.print(Chars2[j]);
                    }
                    if(Chars1[j]<48||(Chars1[j]>57&&Chars1[j]<65)||(Chars1[j]>90&&Chars1[j]<97)||Chars1[j]>125){
                        System.out.print(Chars2[j]);
                    }
                }
                for (int temp : Chars1) {
                    if (temp <= 90 && temp >= 65) {
                        a++;
                    } else if (temp >= 97 && temp <= 125) {
                        b++;
                    } else if (temp >= 48 && temp <= 57) {
                        c++;
                    } else {
                        d++;
                    }
                }
                System.out.println();
                System.out.println("大写字母出现了" + a + "次");
                System.out.println("小写字母出现了" + b + "次");
                System.out.println("数字字母出现了" + c + "次");
                System.out.println("其他字母出现了" + d + "次");
            }
        }

