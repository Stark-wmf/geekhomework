package com.company;

public class Human {
    private String nation="地球人",appreance="两只眼睛，两条腿";
    public void charater(){
        System.out.println("我是"+nation+"有"+appreance);
    }
}
