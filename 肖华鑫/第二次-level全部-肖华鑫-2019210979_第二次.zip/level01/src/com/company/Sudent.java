package com.company;

public class Sudent extends Human{
    private String name="xhx",sex="男";
    private int number=2019,age=18;
    public  void Introuduce(){
        System.out.println("大家好，我的姓名是"+name+"性别是"+sex+"年龄是"+age+"学号是"+number);
    }

    public String getName() {
        return name;
    }

    public String getSex() {
        return sex;
    }

    public int getAge() {
        return age;
    }

    public int getNumber() {
        return number;
    }
}
