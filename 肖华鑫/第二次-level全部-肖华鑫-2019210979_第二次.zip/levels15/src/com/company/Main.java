package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        System.out.println("正在新建一副套牌......");
        Poker poker=new Poker();
	    Shuffle shuffle=new Shuffle();
	    poker.getPoker();
        System.out.println("洗牌顺序如下.......");
	    shuffle.shuffle();
        Player1 player1=new Player1();
        Player2 player2=new Player2();
        System.out.println("请输入一共需要多少张牌？");
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        player1.getCard(a);
        player2.getCard(a);
    }
}
