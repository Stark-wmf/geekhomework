package com.company;
import java.util.Random;
public class Shuffle extends Poker {
    Random random=new Random();
   public void shuffle() {

      for(int i=0;i<=51;i++){
          int a=random.nextInt();
          if(a<0){
              a=-a;
          }
          int b=a%53;
          String temp1=pokers1[i];
          pokers1[i]=pokers1[b];
          pokers1[b]=temp1;
          String temp2=pokers2[i];
          pokers2[i]=pokers2[b];
          pokers2[b]=temp2;
      }
       for (int i=0;i<=53;i++) {
           System.out.println(pokers1[i]+" "+pokers2[i]);
       }

   }
    public String[] getPokers2() {
        return pokers1;
    }
    public String[] getPokers1() {
        return pokers2;

    }
}
