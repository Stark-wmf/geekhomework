package com.company;

public class Player1 extends Poker  {

    public void getCard(int a) {
        System.out.println("玩家1的抽牌为");
            if (a % 2 == 1) {
            for (int j = 0; j <= a-1; j = j + 2) {
                System.out.println(pokers1[j] + " " + pokers2[j]);
            }
        } else {
            for (int j = 0; j <= a-1 ; j = j + 2) {
                System.out.println(pokers1[j] + " " + pokers2[j]);
            }
        }
    }
}

