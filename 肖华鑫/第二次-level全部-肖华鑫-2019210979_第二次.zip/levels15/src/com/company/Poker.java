package com.company;

public class Poker {
    public String color[]=new String[]{"spades","clubs","hearts","diamonds"};
    public String poker[]=new String[]{"2","3","4","5","6","7","8","9","10","J","Q","K","A"} ;
    public String joker[]=new String[]{"小王","大王"};
    public String pokers1[]=new String[54];
    public String pokers2[]=new String[54];
    private String newPokers;
    public int num1=0;
    public Poker(){

        for (int i=0;i<=3;i++){
            for (int j=0;j<=12;j++) {
                pokers1[num1]=color[i];
                pokers2[num1]=poker[j];
               num1++;
            }
        }
        pokers1 [52]=" ";
        pokers1 [53]=" ";
        pokers2[52]=joker[0];
        pokers2[53]=joker[1];

    }
    public void getPoker(){
        for (int i=0;i<=53;i++) {
            System.out.println(pokers1[i]+" "+pokers2[i]);
        }

    }
    public String[] getPokers(){
        return pokers1;
    }

    public String[] getPokers2() {
        return pokers2;
    }
}
