package com.company;
import java.util.Random;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Random random=new Random();
        int a=random.nextInt();
        int b,c=a%99;
        if(c<0){
            c=-c;
        }
        do {
            System.out.println("请输入猜的两位数字");
            Scanner scanner = new Scanner(System.in);
             b = scanner.nextInt();
             if(c>b){
                 System.out.println("太小了");
             }
             if(c<b){
                 System.out.println("太大了");
             }
             if(b==c){
                 System.out.println("正确");
             }

        }while (c!=b);
    }
}
