public class level3 {
    public static void main(String[] args) {
        System.out.println("用1元，2元，5元凑任意整数金额有；");
        add1();
        System.out.println("\n ");
        System.out.println("用0.1元，0.2元，0.5元凑任意小数金额有：");
        add2();
    }

    public static void add1() {
        int[] temp = {0, 0, 0, 0};
        int[] x = {1, 2, 5};
        temp[0] = x[0] + x[1];
        temp[1] = x[0] + x[2];
        temp[2] = x[1] + x[2];
        temp[3] = x[0] + x[1] + x[2];
        for (int i = 0; i < temp.length; i++) {
            System.out.print(temp[i] + "\t");
        }
    }

    public static void add2() {
        float[] temp = {0, 0, 0, 0};
        float[] x = {0.1f, 0.2f, 0.5f};
        temp[0] = x[0] + x[1];
        temp[1] = x[0] + x[2];
        temp[2] = x[1] + x[2];
        temp[3] = x[0] + x[1] + x[2];
        for (int i = 0; i < temp.length; i++) {
            System.out.print(temp[i] + "\t");

        }
    }
}

