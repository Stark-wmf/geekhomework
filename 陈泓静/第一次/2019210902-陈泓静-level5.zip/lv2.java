public class lv2 {
    public static void main(String[] args){
        java.util.Scanner a = new java.util.Scanner(System.in);
        System.out.print("请输入一个整数：");
        int number = a.nextInt();
        if(number < 2 ){
            System.out.println("不是素数。");
        }
        if(number%2==0 && number!=2){
            System.out.println("不是素数");
        }
        if(number == 2||number == 3){
            System.out.println(number);
        }
        for(int i = 3;i < number;i += 2){
            if(number%i == 0 ){
                System.out.println(number);
            }
        }

    }
}
