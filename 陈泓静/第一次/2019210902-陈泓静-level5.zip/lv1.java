public class lv1 {
    public static void main(String[] args){
    java.util.Scanner s = new java.util.Scanner(System.in);
        System.out.print("请输入您的身高（cm）：");
        double  height = s.nextInt();
        double  a = 30.48;
        double  feet = height/a;
        System.out.println("您的英尺身高为；"+feet);
    }

}
