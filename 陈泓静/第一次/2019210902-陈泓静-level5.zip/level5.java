public class level5 {
    public String print(int num){
        return (num > 9)?""+num:" "+num;
    }
    public void level5a(){
        for(int i = 1;i < 10;i++){
            for(int j = 1;j <= i;j++){
                System.out.print(j+"*"+i+"="+print(i*j)+"\t");
            }
            System.out.println();
        }
    }
    public void level5b(){
        for(int i = 9;i > 0;i--){
        for(int j = 1;j <= i;j++) {
            System.out.print(j + "*" + i + "=" + print(i * j) + "\t");
        }
        System.out.println();
        }
    }
    public void level5c(){
        for(int i = 1;i < 10;i++){
            for(int k = 0;k < 9-i;k++){
                System.out.print("\t");
        }
            for(int j = 1;j <= i;j++){
                System.out.print(j+"*"+i+"="+print(i*j)+"\t");
            }
            System.out.println();
    }
}
    public void level5d(){
        for(int i = 9;i > 0;i--){
            for(int k = 0;k < 9-i;k++){
                System.out.print("\t");
            }
            for(int j = 1;j <=i ;j++){
                System.out.print(j+"*"+i+"="+print(i*j)+"\t");
            }
            System.out.println();
        }
    }
    public static void main(String[] args){
        level5 t = new level5();
        System.out.println("形式1：");
        t.level5a();
        System.out.println("------------------\n");
        System.out.println("形式2：");
        t.level5b();
        System.out.println("------------------\n");
        System.out.println("形式3：");
        t.level5c();
        System.out.println("------------------\n");
        System.out.println("形式4：");
        t.level5d();

    }
}

