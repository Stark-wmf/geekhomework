import java.util.Scanner;

public class level1 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        float m=scanner.nextFloat();
        float foot=0;
        foot= (float) (m*3.28);
        System.out.println("身高"+m+"米是"+foot+"英尺");

    }
}

