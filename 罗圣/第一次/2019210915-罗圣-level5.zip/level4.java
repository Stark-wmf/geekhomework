import java.util.Scanner;
public class level4 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int[] num=new int[10];
       int x;
        x =scanner.nextInt();
        while (x!=-1){
            if (x>=0 && x<=9){
                num[x]++;
            }
            x=scanner.nextInt();
        }
        for (int a=0;a<num.length;a++){
            System.out.println(a+"有"+num[a]);
        }
    }
}

