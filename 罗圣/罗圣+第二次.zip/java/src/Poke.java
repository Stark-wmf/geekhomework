package homework_nromal;

public class Poke {
    //后端作业level  1
    public static void main(String[] args) {
        int[][] a = new int[4][9];
        for(int i=0;i<4;i++){
            for(int j = 0;j<9;j++){
                /*int p = 2;
                char u = ;
                p++;*/
                a[i][0] = 2;
                a[i][1] = 3;
                a[i][2] = 4;
                a[i][3] = 5;
                a[i][4] = 6;
                a[i][5] = 7;
                a[i][6] = 8;
                a[i][7] = 9;
                a[i][8] = 10;
                }
            }
        char[][] b = new char[4][4];
        for(int w =0;w<4;w++){
            b[w][0] = 'J';
            b[w][1] = 'Q';
            b[w][2] = 'K';
            b[w][3] = 'A';
        }
        for (int o = 0;o<9;o++) {
            System.out.println("spades " + a[0][o]);
            System.out.println("clubs " + a[0][o]);
            System.out.println("hearts " + a[0][o]);
            System.out.println("diamonds " + a[0][o]);
        }
        for(int e = 0;e<4;e++){
            System.out.println("spades " + b[0][e]);
            System.out.println("clubs " + b[0][e]);
            System.out.println("hearts " + b[0][e]);
            System.out.println("diamonds " + b[0][e]);
            System.out.println("red joker");
            System.out.println("black joker");
        }
        }
}
