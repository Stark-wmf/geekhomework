package homework_nromal;
//level 3
import java.util.Scanner;

public class Level3 {
    public static void main(String[] args) {
        System.out.println("请输入一行字符串");
        Scanner sc = new Scanner(System.in);
        String str = sc.next();
        char[] arr = str.toCharArray();
        int a = 0;//大写字母
        int b = 0;//小写字母
        int c = 0;//数字
        int d = 0;//其他
        for (int i = 0; i < str.length(); i++) {
            // 注意在输入的时候如果输入了空格则统计出错
            char charAt = str.charAt(i);
            if (charAt >= 'A' && charAt <= 'Z') {
                a++;
            } else if (charAt >= 'a' && charAt <= 'z') {
                b++;
            } else if (charAt >= '0' && charAt <= '9') {
                c++;
            } else {
                d++;
            }
        }
        System.out.println("大写字母有"+a);
        System.out.println("小写字母有"+b);
        System.out.println("数字有"+c);
        System.out.println("其他字符有"+d);
    }
}
