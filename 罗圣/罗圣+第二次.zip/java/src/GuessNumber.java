package homework_nromal;

import java.util.Scanner;
//后端作业  level 2
public class GuessNumber {
    public static void main(String[] args) {
        int x=(int)(Math.random()*100);
        System.out.println("请输入一个数字");
        Scanner in = new Scanner(System.in);
        int your = in.nextInt();
        while(your!=x){
            if (your<x){
                System.out.println("太小了");
                System.out.println("请再输入一个数");
                your = in.nextInt();
            }
            else{
                System.out.println("太大了");
                System.out.println("请再输入一个数");
                your = in.nextInt();
            }

        }
        if(your==x){
            System.out.println("猜中了");
        }
    }
}
