package homework_easy;
//后端作业  0.1   &0.2
public class Human {
    int age;
    String name;
    String sex;
    int studyCode;
    public void introduce(){
        System.out.println("姓名为"+name+"，年龄为"+age+"，性别为"+sex+"，学号为"+studyCode);
    }
    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getStudyCode() {
        return studyCode;
    }

    public void setStudyCode(int studyCode) {
        this.studyCode = studyCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
