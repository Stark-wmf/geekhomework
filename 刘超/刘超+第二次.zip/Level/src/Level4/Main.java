package Level4;

public class Main {
    public static void main(String[] args) {
        Player p = new Player();
        p.getCard();
    }
}
