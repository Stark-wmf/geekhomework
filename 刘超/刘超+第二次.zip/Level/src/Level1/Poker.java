package Level1;

import java.util.ArrayList;
import java.util.List;

//为 Level 1 提供洗牌方法和抽牌方法，再加上两个玩家，让玩家能摸牌，最后输出玩家的手牌
//洗牌尽量均匀
//抽牌从顶上第一张开始抽
//玩家也应该是一个类
//玩家的抽的牌数可以任意设置
public class Poker {
        String a[] = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        String b[] = {"spades", "clubs", "hearts", "diamonds"};
        String d[] = {"小王", "大王"};
}
