import java.util.Scanner;

public class Level2 {
    public static void main(String[] args) {
        int a = (int)(Math.random()*10);
        Scanner input = new Scanner(System.in);
        System.out.println("请输入你猜想的数：");

        for (;;){
        int b = input.nextInt();
        if (a<b){
            System.out.println("您猜的数太大了，请重试！");
        }else if (a>b){
            System.out.println("您猜的数太小了，请重试！");
        }else{
            System.out.println("恭喜您猜中了！游戏结束！");
        }
    }
    }
}
