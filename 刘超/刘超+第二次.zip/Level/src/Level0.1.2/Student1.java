package hhh;
public class Student1  {
  public static void main(String[] args) {
      Student a = new Student("刘超", 18, "男", "2019211301", "帅气逼人", "短发");
      a.introduce();
      a.eat();
      a.tall ="190cm";
      System.out.println("学生的身高："+a.tall);

  }
}


