package hhh;

public class Human {
    public String tall;
    public void eat(){
        System.out.println("喜欢吃甜食");
    }
}
