import java.util.Scanner;

public class level3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int a = input.nextInt();
        int i, b, c;
        for (i = 0; i <= a / 5; i++) {
            for (b = 0; b <= (a - i * 5) / 2; b++) {
                for (c = 1; c <=a; c++) {
                    c = a-i*5-b*2;
                    System.out.println(i+"五元 "+b+"二元 "+c+"一元");
                    break;
                }
                }
                }
                 float d = input.nextFloat();
                 float h;
                 for (int e = 0;e<=d/0.5;e++){
                     for (int f = 0;f<=(d-e*0.5)/0.2;f++){
                         for (int g = 1;g<=d/0.1;g++){
                              h = (float)((d-e*0.5-f*0.2)/0.1);
                              int j = (int)h;
                             System.out.println(e+"五角 "+f+"二角"+j+"一角");
                             break;
                         }
                     }
                 }



                    }}


