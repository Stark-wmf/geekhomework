public class level5 {
    public static void s (int a,int b){
        int sss[][]=new int[10][10];
        for (int i = a;i<sss.length;i++){
            for (int j = b;j<i+1;j++)
            {
                sss[i][j]=i*j;
                System.out.print(j+"*"+i+"="+sss[i][j]+"\t");
            }
        System.out.println();
        }
        System.out.println("************************************************************************************");
        for (int i = a+8;i>0;i--){
            for (int j =b;j<i+1;j++){
                sss[i][j]=i*j;
                System.out.print(j+"*"+i+"="+sss[i][j]+"\t");
            }
            System.out.println();
        } System.out.println("************************************************************************************");
        for (int i = a; i <= 9; i++) {
            for (int k = b; k <= 9 - i; k++) {
                System.out.print("      \t");
            }
            for (int j = 1; j <= i; j++) {
                System.out.print(j + "*" + i + "=" + (i * j) + "\t");
            }
            System.out.println();
        } System.out.println("************************************************************************************");
        for (int i =1;i<=9;i++){
            for (int j =i;j<=9;j++){
            System.out.print(j + "*" + i + "=" + (i * j) + "\t");
            } System.out.println();
            for (int k =0;k<i;k++){
                System.out.print("  \t\t");
            }
        }
        }

        public static void main(String[] args) {
        s(1,1);
    }
    }


