package level_6_2;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Test {
    public static void main(String[] args) {
                File file=new File("E:\\BaiduNetdiskDownload\\新建文件夹 (2)\\diyizhou\\src");
                 read(file);
            }

            public static File read(File file) {
                List<File> listf = new ArrayList();
               File[] files = file.listFiles();
              if (files != null) {
            for (File fi : files) {
                if(file.exists()){
                    //将目录添加进集合
                    listf.add(read(fi));
                    //遍历目录集合
                    for(File list:listf){
                        //如果包含“.java”文件，则输出该路径
                        if(list.toString().endsWith(".java")){
                            System.out.println(list);
                        }
                    }
                }else{
                    //将文件添加进集合
                    listf.add(fi);
                    //遍历文件
                    for(File list:listf){
                        //如果文件后缀为“.java”，则输出文件所在路径
                        if(list.toString().endsWith(".java")){
                            System.out.println(list);
                        }
                    }
                }
            }
              }
              return file;
    }
 }

