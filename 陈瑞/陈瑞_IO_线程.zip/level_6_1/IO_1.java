package level_6_1;
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
public class IO_1 {
    //存放文件夹
    public static ArrayList<String> a =new ArrayList<>();
    //存放文件名
    public static ArrayList<String> b=new ArrayList<>();

    public static void isFile(File file){
        //检查一个对象是否是文件夹。返回值是boolean类型的。如果是则返回true，否则返回false。
        if(file.isDirectory()){
            //把文件夹的名字存入dirs集合中
            a.add(file.getName());
            //listFiles()方法是返回某个目录下所有文件和目录的绝对路径，返回的是File数组
            File[] list=file.listFiles();
            for(File f : list){
                isFile(f);
            }
        }else{
            b.add(file.getName());
        }
    }

    public static void main(String []args){
        //接收从键盘输入的路径
        String filePath;
        Scanner in = new Scanner(System.in);
        filePath=in.nextLine();
        File file=new File(filePath);
        isFile(file);
        System.out.println("文件夹有："+IO_1.a.size()+"个");
       for (String dir : IO_1.a){
            System.out.printf("%20s",dir);
            System.out.println("                     ");
        }

        System.out.println("----------------------------------------------------------------------------------------------");
        System.out.println("文件有："+IO_1.b.size()+"个");
        for(String f : IO_1.b){
            System.out.printf("%40s",f);
            System.out.println("                ");
        }
    }
}
