package Work3;


public class Test {
    public static void main(String[] args) {
        Queue queue=new Queue();
        new Thread(new Song(queue)).start();
        new Thread(new Sun(queue)).start();



    }
}
