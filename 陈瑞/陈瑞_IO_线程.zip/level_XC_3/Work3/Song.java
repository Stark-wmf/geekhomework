package Work3;

public class Song implements Runnable {
    Queue queue;
    public Song(Queue queue){
        this .queue=queue;
    }
    @Override
    public void run() {
        try {
           queue.getN();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
