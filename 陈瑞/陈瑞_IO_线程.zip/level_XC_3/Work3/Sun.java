package Work3;

public class Sun implements Runnable {
    Queue queue;
    public Sun(Queue queue){
        this.queue=queue;
    }
    @Override
    public void run() {
        int i=1;
        queue.setN(i);
    }
}
