package level_XC_2;

public class Ticket {
    public static void main(String[] args) {
        /**
         * 实例化线程对象
         */
        Station station1 = new Station("窗口一");
        Station station2 = new Station("窗口二");
        Station station3 = new Station("窗口三");
        /**
         * 开始运行
         */
        station1.start();
        station2.start();
        station3.start();

    }
}

class Station extends Thread {
    //设置静态票数
    static int ticket = 40;
    //设置线程锁
    static Object ob = "ThisIsATicket";

    //给线程命名
    public Station(String name) {
        super(name);
    }

    //写run方法
    public void run() {
        sell();
    }

    //售卖方法
    public void sell() {
        while (ticket > 0) {
            synchronized (ob) {					//ob相当于一个钥匙
                /**
                 * 使用同步锁控制票
                 */
                if (ticket > 0) {

                        System.out.println(getName() + "卖了第" + ticket + "张票");
                        ticket--;
              } else {
                    System.out.println("很抱歉，票卖完了");
                }
            }
            /**
             * 让线程休眠时间随机
             */
            try {

                sleep((long) (1000 * Math.random()));
            } //休息一秒
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

