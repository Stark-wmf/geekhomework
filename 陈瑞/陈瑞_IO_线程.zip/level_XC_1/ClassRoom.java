package level_XC_1;

public class ClassRoom {
    Thread Student1,Student2,Teacher;
    ClassRoom()
    {
        Teacher=new Thread(this::run);
       Student1=new Thread(this::run);
    }
    public void run()
    {
        String name=Thread.currentThread().getName();
        if(name.equals("dsy同学"))
        {
            try
            {
                System.out.println("dsy同学睡着了");
                Thread.sleep(1000*10*60);
            }
            catch(InterruptedException e)
            {
                System.out.println(name+"被老师叫醒了");
            }
            Student1.interrupt();
            System.out.println("dsy同学开始认真听讲了");
        }

        else if(name.equals("老师"))
        {
            for(int i=1;i<=3;i++)
            {
                System.out.println("上课！");
                try
                {
                    Thread.sleep(1000);
                }
                catch(InterruptedException e) {}
            }
            Student1.interrupt();
        }
    }
}
