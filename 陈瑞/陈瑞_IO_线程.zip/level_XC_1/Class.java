package level_XC_1;

public class Class {
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        ClassRoom classroom=new ClassRoom();
        classroom.Teacher.setName("老师");
        classroom.Student1.setName("dsy同学");
        classroom.Student1.start();
        classroom.Teacher.start();
    }
}
