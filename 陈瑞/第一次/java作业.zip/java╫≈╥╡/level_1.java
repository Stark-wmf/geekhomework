import java.util.Scanner;

public class level_1<b> {
    public static void main(String[] args){
        //创建Scanner对象
        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入身高");
        double price;
        price=scanner.nextDouble();
        System.out.println("转换后身高是："+(3.2*price));
    }
}
