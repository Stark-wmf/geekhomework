import java.util.Scanner;

public class level3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入数");
        double n = scanner.nextDouble();
        //代表5的字母
        int five;
        //代表2的字母
        int two;
        //代表1的字母
        int one;
        if(n>=1){

        for (one = 0; one <= n; one++) {
            for (two = 0; two <= n / 2; two++) {
                for (five = 0; five <= n / 5; five++) {
                    if (n == one * 1 + two * 2 + five * 5) {
                        System.out.println(one + "张一元;" + two + "张两元;" + five + "张五元");
                    }
                }

                }
            }
        }else {
            if (n < 1) {
                //代表0.1的数字
                int o_one;
                //代表0.2的数字
                int o_two;
                //代表0.5的数字
                int o_five;
                for (o_one = 0; o_one <= n*10; o_one++) {
                    for (o_two = 0; o_two <= n / 0.2; o_two++) {
                        for (o_five = 0; o_five <= n / 0.5; o_five++) {
                            if (n == o_one * 0.1 + o_two * 0.2 + o_five * 0.5) {
                                System.out.println(o_one + "张0.1元；" + o_two + "张0.2元；" + o_five + "张0.5元");
                            }
                        }
                    }
                }
            }
        }


    }
}


