public class LV5 {
    public static void main(String[] args) {
        way();
        way1();
        way2();
        way3();
    }

    public static void way() {
        for (int i = 1; i < 10; i++) {
            for (int j = 1; j <= i; j++) {
                int sum[][] = new int[9][9];
                sum[i - 1][j - 1] = i * j;
                System.out.print(i + "*" + j + "=" + sum[i - 1][j - 1] + " ");
            }
            System.out.println("");
        }
        System.out.println("--------------------------------------");
    }

    public static void way1() {
        for (int i = 9; i > 0; i--) {
            for (int j = 1; j <= i; j++) {
                int sum[][] = new int[9][9];
                sum[i - 1][j - 1] = i * j;
                System.out.print(i + "*" + j + "=" + sum[i - 1][j - 1] + " ");
            }
            System.out.println("");
        }
        System.out.println("------------------------------------------");
    }

    public static void way2() {
        int sum[][] = new int[9][9];
        for (int i = 1; i < 10; i++) {
            for (int j = 0; j < 9 - i; j++)
                System.out.print("     \t");
                for (int z = 1; z <= i; z++) {
                    sum[i - 1][z - 1] = i * z;
                    System.out.print(i + "*" + z + "=" + sum[i - 1][z - 1]+"\t");
                }
            System.out.println("");
    }
        System.out.println("-------------------------------------------------");
}
    public static void way3(){
        int sum[][]=new int[9][9];
        for (int i = 9; i >0 ; i--) {
            for (int j = 9; j>i ; j--)
                System.out.print("     \t");
                for (int k=1;k<=i;k++){
                    sum[i-1][k-1]=i*k;
                    System.out.print(i+"*"+k+"="+sum[i-1][k-1]+"\t");
                }
                System.out.println("");
            }
        }
    }
