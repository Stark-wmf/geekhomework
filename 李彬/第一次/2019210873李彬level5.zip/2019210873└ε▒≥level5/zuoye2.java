package zuoye;
import java.util.Scanner;
public class zuoye2 {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        System.out.print("请输入一个数:");//输入一个数
        int num = in.nextInt();
        int a = 0;//素数的个数
        for (int i = 2; i < num; i++) {
            if (num % i == 0) {
                a++;//素数+1
            }
        }
        if (a == 0) {
            System.out.println(num + "是素数");

        } else {
            System.out.println(num + "不是素数");
        }
    }
}