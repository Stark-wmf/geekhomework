package zuoye;

public class Zuoye5 {
    public String print(int num) {//判断结果是否大于9，如果不大于9前面加一个空格
        return (num > 9) ? "" + num : " " + num;
/*		if(num>9)
			return " "+num;
		else
			return num+"";*/
    }

    public void zuoye51() {
        for (int i = 1; i < 10; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(j + "*" + i + "=" + print(i * j) + "\t");
            }
            System.out.println();
        }
    }

    public void zuoye52() {
        for (int i = 9; i > 0; i--) {
            for (int j = 1; j <= i; j++) {
                System.out.print(j + "*" + i + "=" + print(i * j) + "\t");
            }
            System.out.println();
        }
    }

    public void zuoye53() {
        for (int i = 1; i < 10; i++) {
            for (int k = 0; k < 9 - i; k++) {
                System.out.print("\t");
            }
            for (int j = 1; j <= i; j++) {
                System.out.print(j + "*" + i + "=" + print(i * j) + "\t");
            }
            System.out.println();
        }
    }

    public void zuoye54() {
        for (int i = 9; i > 0; i--) {
            for (int k = 0; k < 9 - i; k++) {
                System.out.print("\t");
            }
            for (int j = 1; j <= i; j++) {
                System.out.print(j + "*" + i + "=" + print(i * j) + "\t");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Zuoye5 t = new Zuoye5();
        System.out.println("形式1：");
        t.zuoye51();
        System.out.println("形式2：");
        t.zuoye52();
        System.out.println("形式3：");
        t.zuoye53();
        System.out.println("形式4：");
        t.zuoye54();
    }
}