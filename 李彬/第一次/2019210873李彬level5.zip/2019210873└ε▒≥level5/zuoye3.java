package zuoye;

import java.util.Scanner;
public class zuoye3 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("请输入一个数：");
        double m = in.nextDouble();
        double w = (int) m;//得到m的整数部分
        int k = (int) ((m - w) * 10);//得到M的小数部分，并乘于10便于计算
        int n=(int)w;//把m的整数部分从实型转为整型
        int x1 = 0, y1 = 0, z1 = 0, num1 = 0;
        int x2 = 0, y2 = 0, z2 = 0;
        int num2 = 0, num = 0;
        for (x1 = 0; x1 <= n; x1++) {
            for (y1 = 0; y1 <= n / 2; y1++) {
                for (z1 = 0; z1 <= n / 5; z1++) {
                    if (x1 + 2 * y1 + 5 * z1 == n) {
                        System.out.println("1元" + x1 + " 个,2元" + y1 + "个,5元" + z1 + "个");
                        num1++;
                    }
                }
            }
        }
        System.out.println("一共有" + num1 + "方法");
      for (x2 = 0; x2 <= k; x2++) {
            for (y2 = 0; y2 <= k / 2; y2++) {
                for (z2 = 0; z2 <= k / 5; z2++) {
                    if (x2 + 2 * y2 + 5 * z2 == k) {
                        System.out.println("0.1元" + x2 + " 个,0.2元" + y2 + ",0.5元" + z2 + "个");
                        num2++;
                    }
                }
            }
        }
        System.out.println("一共有" + num2 + "方法");
        num = num1 * num2;
        System.out.println("一共有" + num + "方法");

    }
}

