package zuoye;
import java.util.Scanner;
public class zuoye1 {
    public static void main(String[] args) {
    Scanner in=new Scanner(System.in);
    System.out.print("请输入一个数：");
    double n=in.nextDouble();
    double m=3.2808399;
    double x=n*m;
        System.out.println(x+"英尺");
}
}