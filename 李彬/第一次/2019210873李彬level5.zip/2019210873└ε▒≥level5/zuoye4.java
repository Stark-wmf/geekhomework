package zuoye;
import java.util.Scanner;
public class  zuoye4 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        int[]numbers =new int[100];
        int num=0;
        int x;
        x= input.nextInt();
        while (x!=-1){
            if (x>=0&&x<=9){
          numbers[x]++;
         x=input.nextInt();
        }
        }
        for (x=0;x<10;x++){
            System.out.println(""+x+"出现了"+numbers[x]+"次");
        }
    }
}
