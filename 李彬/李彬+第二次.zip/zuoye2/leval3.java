package zuoye2;
import zuoye.zuoye2;

import java.util.*;

public class leval3 {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        System.out.println("请输入一行字符串");
        String str = sc.next();
        char[] arr = str.toCharArray();
        int a = 0;//大写字母
        int b = 0;//小写字母
        int c = 0;//数字
        int d = 0;//其他
        //方法一  采用if判断
        for (int i = 0; i < arr.length; i++) {
            // 注意在输入的时候如果输入了空格则统计出错
            char ch = arr[i];
            ArrayList nums = null;
            if (ch >= 'A' && ch <= 'Z') {
                a++;


                continue;

            }
            if (ch >= 'a' && ch <= 'z') {
                b++;
                continue;
            }
            if (ch >= '0' && ch <= '9') {
                c++;
                continue;
            }
            d++;
        }

        System.out.println("大写字母"+a);

        System.out.println("小写字母:"+b);
        System.out.println("数字:"+c);
        System.out.println("其他字符:"+d);

    }
}
