package zuoye2;
import java.util.LinkedList;
public class pukepai {
    public static void main(String[] args) {
        //实例化集合对象
        LinkedList pockers = createPoker();
        showPoker(pockers);//显示多少张牌
    }
    //生成扑克牌的方法
    public static LinkedList createPoker() {
        //该集合用于存储扑克对象
        LinkedList list = new LinkedList();
        //定义数组存储所有的花色和点数
        String[] colors = {"♦", "♣", "♡", "♠"};
        String[] nums = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        String[] daxiaowang = {"小王", "大王"};
        //添加集合中扑克牌
        for (int j = 0; j < colors.length; j++) {
            for (int i = 0; i < nums.length; i++) {

                list.add(new Poker(colors[j], nums[i]));

            }

        }
        list.add("大\uD83D\uDC7B");
        list.add("小\uD83D\uDC7B");//可以直接添加
        return list;
    }
    public static class Poker {
        String color;// 花色
        String num;// 点数
        // 构造方法
        public Poker(String color, String num) {
            super();
            this.color = color;
            this.num = num;
        }
        // 重写toString()
        @Override
        public String toString() {
            return color + num;
        }
    }
    //洗牌的功能
    public static void showPoker(LinkedList pockers) {
        for (int i = 0; i < pockers.size(); i++) {
            System.out.print("  " + pockers.get(i));
            //换行
            if (i % 10 ==9) {
                System.out.println();
            }
        }
        System.out.println();
        System.out.println("牌数:" + pockers.size());//显示多少张牌
    }
}
