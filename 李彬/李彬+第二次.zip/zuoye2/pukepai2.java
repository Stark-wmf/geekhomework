package zuoye2;

import zuoye.zuoye2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class pukepai2 {


    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        HashMap<Integer, String> poker = new HashMap<>();

        //1.准备牌
        String[] colors = new String[]{"红桃", "黑桃", "梅花", "方块"};
        String[] numbers = new String[]{"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        int index = 0;
        poker.put(index, "大王");
        list.add(index);
        index++;
        poker.put(index, "小王");
        list.add(index);
        for (String number : numbers)
            for (String color : colors) {
                index++;
                poker.put(index, color + number);
                list.add(index);
            }
//System.out.println(poker);

        //2.洗牌
        Collections.shuffle(list);
//System.out.println(list);

 /*
            3.发牌
            3个玩家，3张底牌
         */
        ArrayList<Integer> list1 = new ArrayList<>();
        ArrayList<Integer> list2 = new ArrayList<>();
        ArrayList<Integer> list3 = new ArrayList<>();
        ArrayList<Integer> dipai = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            Integer in = list.get(i);
            if (i < 51) {
                //玩家1

                if (i % 3 == 0) {

                    list1.add(list.get(i));
                }
                //玩家2
                else if (i % 3 == 1) {
                    list2.add(list.get(i));
                }
                //玩家3
                else {
                    list3.add(list.get(i));
                }
            } else {
                dipai.add(list.get(i));
            }
        }
/*
            4.排序
         */
        Collections.sort(list1);
        Collections.sort(list2);
        Collections.sort(list3);
        Collections.sort(dipai);
 /*
            5.输出3个玩家的牌面和底牌
         */
        print("玩家1", poker, list1);
        print("玩家2", poker, list2);
        print("玩家3", poker, list3);
        print("底牌", poker, dipai);
    }
//打印玩家或者底牌牌面


    public static void print(String name, HashMap<Integer, String> poker, ArrayList<Integer> list) {
        System.out.print(name + ":");
        for (Integer key : list) {
            System.out.print(poker.get(key) + "\t");
        }
        System.out.println();
    }

}