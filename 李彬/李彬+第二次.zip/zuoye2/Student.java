package zuoye2;

public class Student extends Human{
    private void name(){

        String name="李彬";
        System.out.println("姓名："+name);
    }
    private void age(){
        int age=18;
        System.out.println("年龄："+age);
    }
    private void gender(){

        String gender="男";
        System.out.println("性别："+gender);

    }
    private void xuehao(){
        long xuehao=2019210873;
        System.out.println("学号："+xuehao);
    }
    public static void main(String[] args) {
        Student student=new Student();
        student.name();
        student.age();
        student.gender();
        student.xuehao();
    }
}
