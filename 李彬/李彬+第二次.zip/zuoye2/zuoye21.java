package zuoye2;
import zuoye.zuoye2;

import java.util.Random;
import java.util.Scanner;
public class zuoye21 {
    public static void main(String[] args) {
        Random suiji = new Random();
        int shu = suiji.nextInt(10)+1 ; //用于生成25之间的随机数 接收数据给变量shu;
        System.out.println("猜数字游戏开始");
        System.out.println("请输入一个整数：");
        int i = 0;
        while (true) {
            //由用户输入数字    //用户的输入次数不确定,再此添加while循环
            Scanner shuan = new Scanner(System.in);
            int ru = shuan.nextInt(); //??如何在此去除用户输入的非数字的文本;
            i++; //用于记录用户出入次数
            //判断输入的数字与系统产生的随机数比较;
            if (ru > shu) {
                System.out.println("您输入的数字" + ru + "大了，请重新输入");
            } else if (ru < shu) {
                System.out.println("您输入的数字" + ru + "小了,请重新输入");
            } else {
                System.out.println("恭喜您第" + i + "次猜对了");
            }
        }
    }
}