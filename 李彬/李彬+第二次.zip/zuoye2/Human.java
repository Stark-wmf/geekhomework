package zuoye2;

public class Human {

}
