package lei;
import java.util.Random;
import java.util.Scanner;



public class level2 {


        public static void main(String[] args) {
            Scanner a = new Scanner(System.in);
            System.out.println("请输入一个是100以内的整数:");
            int f =a. nextInt();
            int g = (int) (Math.random()*100 + 1);

            while (g != f) {
                if (g <= f) {
                    System.out.println("偏大,重新来:");
                } else {
                    System.out.println("偏小,重新来:");
                }
                f = a.  nextInt();
            }
            System.out.println("对了,你真是个小机灵鬼!");
        }

    }


