package lei;

import WERR._level3;

class Human extends Student  {
    public static void main(String[] args) {
        Human A =new Human();
        System.out.println(A.getSex());
        System.out.println(A.getAge());
        System.out.println(A.getNumber());
        System.out.println(A.getName());


    }


}
