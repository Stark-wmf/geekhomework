package lei;

public class level1 {
    static class Poke{

    }

    public static void main(String[] args) {
        Poke a= new Poke();
        int numbers1[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
        String colors[]={"spades","clubs","hearts","diamonds"};
        for(int i=1;i<=numbers1.length;i++){
            String sign ="";
            if(i==1){
                sign ="A";
                for(int i1 =0;i1<colors.length;i++){
                    System.out.println(colors[i1]+sign);
                }

            }
            else if(i==11){
                sign ="J";
                for(int i1 =0;i1<colors.length;i++){
                    System.out.println(colors[i1]+sign);
                }
            }
            else if(i==12){
                sign ="Q";
                for(int i1 =0;i1<colors.length;i++){
                    System.out.println(colors[i1]+sign);
                }
            }
            else if(i==13){
                sign ="K";
                for(int i1 =0;i1<colors.length;i++){
                    System.out.println(colors[i1]+sign);

                }
            }
            else if(i==14){
                sign ="BIG";
                System.out.println(sign);
            }
            else if(i==15){
                sign ="SMALL";
                System.out.println(sign);

            }
            else{
                for(int i1 =0;i1<colors.length;i++){
                    System.out.println(colors[i1]+colors[i]);
                }

            }



        }




    }
}
