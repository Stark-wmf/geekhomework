package lei;

 class Student {
     private int age;
     private String name;
     private int number;
     private String sex;

     public void introduce() {
         System.out.println(
                 "我的名字为" + name + "性别为" + sex + "年龄为" + age + "学号为" + number);


     }

     public static class level01 {
         public static void main(String[] args) {
             Student student = new Student();
             student.name = "陈信宏";
             student.age = 18;
             student.sex = "雌雄共体";
             student.number = 20190101;
             student.introduce();

         }
     }
     public int getAge(){
         return age;
     }
     public int getNumber(){
         return number;
     }
     public String getName(){
         return name;
     }
     public String getSex(){
         return sex;
     }
 }


