package WERR;

public class whi {
    public static void main (String[] args){
        int num = 0;
        int n =1;
        while (n<=100) {
            num = num+n;
            n++;
        }System.out.println(num);
    }


}
