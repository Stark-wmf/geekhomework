package WERR;

public class form {
    public static void main(String[] args){
        int count = 0;
        for (int i=1;i<=1000;i++){
            count= count+i;
        }
        System.out.println(count);
    }
}
