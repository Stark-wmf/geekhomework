package WERR;

public class foewhile {
    public static void main(String[] args){
        int num= 0;
        for(int i=1; i<=4; i++){
            for(int u=1; u<=4; u++){
                for(int y=1; y<=4; y++){
                    for(int t=1; t<=4; t++){
                        if(i !=u&&i !=y&&i !=t){
                            int r=i+10*u+100*y+1000*t;
                            System.out.println(r);
                        }
                    }
                }
            }
        }
        System.out.println(num);
    }
}
