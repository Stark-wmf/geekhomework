package WERR;

import java.util.Scanner;

public class nei {
    public static void main(String[] args){
        Scanner A = new Scanner(System.in);
        System.out.println("请输入内鬼：");
        int num = A.nextInt();
        int i=1;
        while(i !=num){
            System.out.println(i+"不是内鬼");
            i++;
        }
        System.out.println(i+"是内鬼");

    }
}
