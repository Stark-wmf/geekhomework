package WERR;

import java.util.Scanner;

public class levle2 {
    public static void main(String[] arg){
        Scanner shusu=new Scanner(System.in);
        System.out.println("请输入一个数字");
        int i=shusu. nextInt();
        boolean isshusu = true;
        for(int a=2;a<i;a++){
            if(i%a==0) {
                isshusu = false;
                break;

            }
            }

        System.out.println(isshusu ? i +"是素数" : i+ "不是素数");
            }

            }




