package WERR;

import java.util.Scanner;

public class level1 {
    public static void main(String[] args){
        Scanner shenggao = new Scanner(System.in);
        System.out.println("请输入姚明的身高");
        double i=shenggao.nextDouble();
        double f=i*3.2808;
        System.out.println(f+"英尺");


    }

}
