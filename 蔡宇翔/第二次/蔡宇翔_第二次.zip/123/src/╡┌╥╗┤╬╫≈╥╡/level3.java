package WERR;

import java.util.Scanner;

public class level3 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("请输入一个钱数：");
        double m = in.nextDouble();
        double w = (int) m;//得到m的整数部分
        int k = (int) ((m - w) * 10);//得到m的小数部分，并乘于10便于计算
        int n = (int) w;//把m的整数部分从实型转为整型
        int a1 = 0, b1 = 0, c1 = 0, num1 = 0;
        int a2 = 0, b2 = 0, c2 = 0;
        int num2 = 0, num = 0;
        for (a1 = 0; a1 <= n; a1++) {
            for (b1 = 0; b1 <= n / 2; b1++) {
                for (c1 = 0; c1 <= n / 5; c1++) {
                    if (a1 + 2 * b1 + 5 * c1 == n) {
                        System.out.println("1元" + a1 + " 个,2元" + b1 + "个,5元" + c1 + "个");
                        num1++;
                    }
                }
            }
        }
        System.out.println("一共有" + num1 + "方法");
        for (a2 = 0; a2 <= k; a2++) {
            for (b2 = 0; b2 <= k / 2; b2++) {
                for (c2 = 0; c2 <= k / 5; c2++) {
                    if (a2 + 2 * b2 + 5 * c2 == k) {
                        System.out.println("0.1元" + a2 + " 个,0.2元" + b2 + ",0.5元" + c2 + "个");
                        num2++;
                    }
                }
            }
        }
        System.out.println("一共有" + num2 + "方法");
        num = num1 * num2;
        System.out.println("一共有" + num + "方法");

    }
}