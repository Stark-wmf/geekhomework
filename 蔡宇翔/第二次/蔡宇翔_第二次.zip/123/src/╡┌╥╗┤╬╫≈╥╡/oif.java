package WERR;

import java.util.Scanner;

public class oif {
    public static void main(String[] args){
        Scanner a = new Scanner(System.in);
        System.out.println("qingshulunidemingzi");
        int num =a.nextInt();
        if (num>=60&&num<80) {
            System. out. println("你及格了");
        }else if(num>=80&&num<100){
          System .out. println("你很优秀");
        }    }
}
