package WERR;

import java.util.Scanner;

public class _level3 {
    public static void main(String[] args){
        Scanner in= new Scanner(System.in);
        System.out.println("请输入你的钱数：");
        double money=in. nextDouble();
        double z= (int) money;
        int x= (int)((money-z)*10);
        int z1=(int) z;

        int a,b,c,a1,b1,c1=0;
        int num1=0;
        int num2=0;
        int num=0;
        for(a=0;a<=z1;a++){
            for(b=0;b<=z1/2;b++){
                for(c=0;c<=z1/5;c++){
                    if(z==a+2*b+5*c){
                        System.out.println("一元硬币"+a+"个    两元纸币"+b+"张    五元纸币"+c+"张" );
                        num1++;
                    }
                }
            }
        }
        System.out.println("整数上有"+num1+"种方法");
        for(a1=0;a1<= x;a1++){
            for(b1=0;b1<= x/2;b1++){
                for(c1=0;c1<= x/5;c1++){
                    if(x==a1 +b1*2 + c1*5){
                        System.out.println("一毛硬币"+a1+"个    两毛纸币"+b1+"张    五毛纸币"+c1+"张" );
                        num2++;


                    }
                }
            }
        }
        System.out.println("小数上有"+num2+"种方法");
        num= num1* num2;
        System.out.println("总共有"+num+"种方法");
    }


    }

