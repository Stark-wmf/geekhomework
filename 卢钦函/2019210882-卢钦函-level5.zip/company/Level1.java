package com.company;

public class Level1 {
    public static void main(String[] args) {
        double y = 3.2808399;
        double h = 2.26;
        double h1 = y * h;
        System.out.println("姚明的身高为"+ h1 +"英尺");
    }
}
