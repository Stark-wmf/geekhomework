package com.company;

import java.util.Scanner;
public class Level2 {
    public static void main(String[] args){
        Scanner s = new Scanner(System.in);
        System.out.print("请输入数字：");
        int a = s.nextInt();
        for(int i = 2;i<=a;i++){
            if(a % i == 0&& i != a) {
                System.out.println("不是素数");
                break;
            }
            else if(i == a){
                System.out.println(a);
            }

        }

    }

}