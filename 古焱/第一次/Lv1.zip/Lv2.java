import java.util.Scanner;

public class Lv2 {
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    int pn = scanner.nextInt();
    for (int n = 2; n <= pn; n++)
    if (pn % n == 0) {
    if (pn / n == 1) {
    System.out.println(pn + "是素数");
    } else {
    System.out.println(pn + "不是素数");
    break;
    }
    }
    }}