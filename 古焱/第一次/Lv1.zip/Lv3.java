import java.util.Scanner;

public class Lv3 {
    public static void main(String[] args) {
    Scanner scanner=new Scanner(System.in);
    double n=scanner.nextDouble();
    int z;
    z=(int) n;
    if (n==z)
    { int x, y, v;//x是一元y是二元z是五元
            for (x = 1;x<=n;x++ ){
                for (y=1;y<n/2;y++){
                    for (v=1;v<n/5;v++){
                        if (x+2*y+5*v==n){
                            System.out.println("要"+x+"个一元"+y+"个二元"+z+"个五元得到"+n);
                        }
                    }
                }
            }
        }
        else if (n!=z)
    { int a,b,c;//a是0.1,元b是0.2元，c是0.5元。
            for (a=1;a<n*10;a++){
                for (b=1;b<n*5;b++){
                    for (c=1;c<n*2;c++){
                        if (0.1*a+0.2*b+0.5*c==n){
                            System.out.println("要"+a+"个0.1元"+b+"个0.2"+c+"个0.5");
                        }
                    }
                }
            }
        }


    }
}