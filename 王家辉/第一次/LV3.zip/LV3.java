import java.util.Scanner;
public class LV3 {
    public static void main(String[] args) {
        double a;
        Scanner b = new Scanner(System.in);
        a = b.nextDouble();
        int f = (int) a / 5;
        for (int i = f; i >= 0; i--) {
        int c = (int) (a - i * 5) / 2;
            for (int j = 0; j <= c; j++) {
            int d = (int) a - i * 5 - j * 2;
            double g = a - (int) a;
            int h = (int) (g * 2);
            for (int q = h; q >= 0; q--) {
            int l = (int) ((g - q * 0.5) * 5);
            for (int w = 0; w <= l; w++) {
            int p = (int) ((g - q * 0.5 - w * 0.2) * 10);
System.out.println("一元" + d + " 两元 " + j + " 五元" + i + " 一角" + p + " 二角" + w + " 五角" + q);
                    }
                }
            }
        }
    }
}


