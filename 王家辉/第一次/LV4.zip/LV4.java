import java.util.Scanner;
public class LV4 {
    public static void main(String[] args) {
        Scanner a=new Scanner(System.in);
        int b;
        int[] c=new int[10];
        b=a.nextInt();
        while (b!=-1){
            if (b>=0&&b<10){
                c[b]++;
            }
            b=a.nextInt();
        }
        for (int i = 0; i <c.length ; i++) {
            System.out.println(i+"出现次数："+c[i]);
        }
    }
}
