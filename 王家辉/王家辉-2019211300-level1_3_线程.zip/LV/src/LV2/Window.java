package LV2;

public class Window implements Runnable{
    private int ticket=40;
    public void run() {
        for (int i = 0; i <50 ; i++) {
            if (ticket>0){
                System.out.println( Thread.currentThread().getName()+"窗口卖出第"+ticket--+"张票");
            }
        }
    }
}
