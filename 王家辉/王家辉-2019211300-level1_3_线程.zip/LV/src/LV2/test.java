package LV2;

public class test {
    public static void main(String[] args) {
        Window a=new Window();
        Thread window1=new Thread(a,"no1");
        Thread window2=new Thread(a,"no2");
        Thread window3=new Thread(a,"no3");
        window1.start();
        window2.start();
        window3.start();
    }
}
