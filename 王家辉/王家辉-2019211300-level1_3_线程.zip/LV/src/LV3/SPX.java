package LV3;

import static LV3.SL.latiao;

public class SPX implements Runnable {
    private int spxmoney = 5;
    private String name;

    public SPX(String name) {
        this.name = name;
    }

    public void run() {
        for (int i = 0; i < 10; i++) {
            while (spxmoney >= 5 && latiao > 0) {
                System.out.println(name+"同学买到了辣条并且幸福的吃了起来");
                spxmoney = spxmoney - 5;
                latiao = latiao - 1;
            }
        }
    }
}
