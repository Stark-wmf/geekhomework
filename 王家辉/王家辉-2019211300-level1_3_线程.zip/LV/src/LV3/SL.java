package LV3;

public class SL implements Runnable {
    static public int latiao = 2;
    private int slmoney = 10;
    private String name;
    public SL(String name) {
        this.name = name;
    }
    public void run() {
        for (int i=0;i<10;i++) {
            while (slmoney >= 5 && latiao > 0) {
                if (i == 0) {
                    System.out.println(name+"同学先到了小卖部");
                    System.out.println(name+"同学等待spx同学到小卖部买辣条");
                    SPX q=new SPX("spx");
                    q.run();
                    break;
                }
                else  {
                    System.out.println("sl买到了辣条并和spx一起吃上了辣条");
                    slmoney = slmoney - 5;
                    latiao = latiao - 1;
                }
            }
        }
    }
}
