package LV3;

public class test {
    public static void main(String[] args) {
        SL a = new SL("sl");
        Thread b = new Thread(a);
        b.start();
    }
}

