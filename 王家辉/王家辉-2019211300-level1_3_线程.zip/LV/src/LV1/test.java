package LV1;


public class test {
    public static void main(String[] args) {
        Student a=new Student();
        Teacher c=new Teacher();
        Thread b=new Thread(a,"dsy");
        Thread d=new Thread(c,"老师");
        b.start();
        d.start();
        }
    }

