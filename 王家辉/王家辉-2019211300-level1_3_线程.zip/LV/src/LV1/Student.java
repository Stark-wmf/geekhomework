package LV1;

public class Student implements Runnable {
    public void run() {
        for (int i = 0; i <3 ; i++) {
            while (i==0){
                System.out.println("dsy同学睡着了");
                break;
            }
            if (i==0) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                }
            }
            while (i==1){
                System.out.println("dsy被老师叫醒了");
                break;
            }
            while (i==2){
                System.out.println("dsy同学开始认真听讲");
                break;
            }
        }
    }
}
