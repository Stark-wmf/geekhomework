package LV1;

public class Teacher implements Runnable {
    public void run() {
        for (int i = 0; i < 3; i++) {
            if (i == 0) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("上课！");
            } else {
                System.out.println("上课！");
            }
        }
    }
}
