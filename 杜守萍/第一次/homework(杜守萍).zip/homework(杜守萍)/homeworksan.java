import nextFloat.nextFloat;

import java.util.Scanner;

public class homeworksan {
    public static void main(String args[])
    {
        Scanner scanners = new Scanner(System.in);
        System.out.println("请输入钱数");
        Double money = scanners.nextDouble();
        double i=0.1,j=0.2,k=0.5;
                for(i=0;i<money;i++)
                {
                    for (j = 0; j < money; j++)
                    {
                     for (k=0;k<money;k++)
                     {
                        System.out.println("一角的硬币数为："+i+"两角的硬币数为："+j+"五角的硬币数为:"+k);
                     }
                    }
                }

    }
}
