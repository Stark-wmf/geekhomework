import java.util.Scanner;

public class homework3 {
    public static void main(String args[])
    {
        Scanner scanners=new  Scanner  (System.in);
        System.out.println("请输入钱数");
        String money=scanners.nextLine();
        int i=1,j=2,k=5;
        double a=Integer.valueOf(money);
        for (i=0;i<a; i++)
        {
            for ( j = 0; j<=(a-5*i) /2;j++)
            {
                for (k = 0; k <=a-5*i-2*j ; k++)
                {
                    System.out.println("一块的硬币数为:"+i+"两块的硬币数为:"+j+"五块的硬币数为:"+k);


                }
            }


        }
    }
}
