package hjjk;

import java.util.Scanner;

public class feet {
    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("Metres");
        double metres=scanner.nextDouble();
        metres=metres*3.28;
            System.out.print(metres);
        }
    }

