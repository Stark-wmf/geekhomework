import java.util.Scanner;

public class zuoye2 {
    public static void main (String [] args){
        Scanner scanners=new Scanner (System.in);
        System.out.println("请输入数字");
        int num = scanners.nextInt ();
        for (int a=2;a<=num;a=1){
            if (a==num){
                System.out.println("是素数");
            break;}
                else if (num%a==0&&a!=num){
                    System.out.println("不是素数");
                    break;
                }
            }
        }



    }

