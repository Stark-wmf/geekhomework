package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.print("请输入你的身高(m)：");
        double a=scanner.nextDouble();
        double b=a/0.3048;
        System.out.println("你身高"+b+"英尺");
    }
}