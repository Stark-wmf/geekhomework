package com.company;
public class Main {
    public void one(){
        int[][]a =new int[9][9];
        for(int i=0;i<9;i++){
            for (int j=0;j<=i;j++){
                a[i][j]=(i+1)*(j+1);
                System.out.print((i+1)+"*"+(j+1)+"="+a[i][j]+"\t");
            }
            System.out.println();
        }
    }
    public void tow(){
        int[][] a = new int[9][9];
        for(int i=8;i>=0;i--) {
            for (int j =i; j >= 0; j--) {
                a[i][j] = (i + 1) * (j + 1);
                System.out.print((i+1)+"*"+(j+1)+"="+a[i][j]+"\t");
            }
            System.out.println();
        }
    }
    public void three(){
        int[][] a = new int[9][9];
        String w="     \t";
        for(int i=8;i>=0;i--) {
            for (int q=i;q<8;q++){
            System.out.print(w);
            }
            for (int j =i; j >= 0; j--) {
                a[i][j]=(i+1)*(j+1);
                System.out.print((i+1)+"*"+(j+1)+"="+a[i][j]+"\t");
            }
            System.out.println();
        }

    }
    public void four(){
        int[][] a = new int[9][9];
        String w="     \t";
        for(int i=0;i<9;i++){
            for (int q=i;q<8;q++){
                System.out.print(w);
            }
            for (int j=0;j<=i;j++){
                a[i][j] = (i + 1) * (j + 1);
                System.out.print((i+1)+"*"+(j+1)+"="+a[i][j]+"\t");
            }
            System.out.println();
        }

    }
    public static void main(String[] args) {
        Main test=new Main();
        test.one();
        System.out.println();
        test.tow();
        System.out.println();
        test.three();
        System.out.println();
        test.four();
    }
}

