package com.company;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("请输入一个金额：");
        float money = scanner.nextFloat();
        int x = (int) money;
        float w = (money - x)*10;
        int j,a,b;
        if (w%5!=0){
            j=(int)w+1;
        }else {
            j=(int)w;
        }
        int y = x / 5;
        for (a = y; a >= 0; a--) {
            int z = x - a * 5;
            int i = z / 2;
            for (b = i; b >= 0; b--) {
                int p = z - b * 2;
                for (int NI=j/5;NI>=0;NI--) {
                    for (int WO=(j-NI*5)/2; WO >= 0; WO--) {
                        int TA=(j-NI*5)-WO*2;
                        System.out.println(x + "是由" + a + "张5元" + b + "张2元" + p + "张1元" + NI + "张0.5元" + WO + "张0.2元" + TA + "张0.1元");
                    }
                }


            }
        }
    }
}