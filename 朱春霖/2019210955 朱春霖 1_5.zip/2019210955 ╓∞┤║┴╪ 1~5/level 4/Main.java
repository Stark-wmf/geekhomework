package com.company;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        int[] count={0,1,2,3,4,5,6,7,8,9};
        int sore0=0,sore1=0,sore2=0,sore3=0,sore4=0,sore5=0,sore6=0,sore7=0,sore8=0,sore9=0;
        Scanner scanner=new Scanner(System.in);
        for (int i=0;i<100;i++) {
            System.out.print("请输入0~9之间的数：");
            int a = scanner.nextInt();
            if (a == count[0]) {
                sore0++;
            }
            if (a == count[1]) {
                sore1++;
            }
            if (a == count[2]) {
                sore2++;
            }
            if (a == count[3]) {
                sore3++;
            }
            if (a == count[4]) {
                sore4++;
            }
            if (a == count[5]) {
                sore5++;
            }
            if (a == count[6]) {
                sore6++;
            }
            if (a == count[7]) {
                sore7++;
            }
            if (a == count[8]) {
                sore8++;
            }
            if (a == count[9]) {
                sore9++;
            }
            if (a == -1) {
                break;
            }
        }
        System.out.println("0出现了"+sore0+"次，1出现了"+sore1+"次，2出现了"+sore2+"次，3出现了"+sore3+"次，4出现了"+sore4+"次，5出现了"+sore5+"次，6出现了"+sore6+"次，7出现了"+sore7+"次，8出现了"+sore8+"次，9出现了"+sore9 +"次");
       }
    }
