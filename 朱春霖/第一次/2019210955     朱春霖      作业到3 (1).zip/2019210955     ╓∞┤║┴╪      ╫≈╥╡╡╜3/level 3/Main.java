package com.company;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.print("请输入一个整数金额：");
        int x=scanner.nextInt();
        int y=x/5;
        int a,b,c;
        for (a=y;a>=0;a--){
            int z=x-a*5;
            int i=z/2;
            for (b=i;b>=0;b--){
                int p=z-i*2;
                System.out.println(x+"是由"+a+"张5元"+b+"张2元"+p+"张1元");
            }

        }
        }
        }